(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var orion;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                              //
// packages/orionjs_base/init.js                                                                //
//                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                //
orion = {};                                                                                     // 1
                                                                                                // 2
//////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                              //
// packages/orionjs_base/helpers.js                                                             //
//                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                //
/**                                                                                             // 1
 * Orion Helpers                                                                                // 2
 */                                                                                             // 3
orion.helpers = {};                                                                             // 4
                                                                                                // 5
/**                                                                                             // 6
 * Searchs a object with a givin string                                                         // 7
 * you can specify if you want the searcher to                                                  // 8
 * take the first values of array if they are                                                   // 9
 */                                                                                             // 10
orion.helpers.searchObjectWithDots = function(object, key, selectFirstIfIsArray) {              // 11
  key = key.split('.');                                                                         // 12
                                                                                                // 13
  try {                                                                                         // 14
    for (var i = 0; i < key.length; i++) {                                                      // 15
      if (selectFirstIfIsArray && object.length && object.length > 0) {                         // 16
        object = object[0];                                                                     // 17
      }                                                                                         // 18
      if (key[i] in object) {                                                                   // 19
        object = object[key[i]];                                                                // 20
      } else {                                                                                  // 21
        return undefined;                                                                       // 22
      }                                                                                         // 23
    }                                                                                           // 24
  } catch(error) {                                                                              // 25
    return undefined;                                                                           // 26
  }                                                                                             // 27
                                                                                                // 28
  return object;                                                                                // 29
};                                                                                              // 30
                                                                                                // 31
/**                                                                                             // 32
 * Deep extend                                                                                  // 33
 */                                                                                             // 34
orion.helpers.deepExtend = function(target, source) {                                           // 35
  for (var prop in source)                                                                      // 36
    if (prop in target && typeof(target[prop]) == 'object' && typeof(source[prop]) == 'object')
      orion.helpers.deepExtend(target[prop], source[prop]);                                     // 38
    else                                                                                        // 39
      target[prop] = source[prop];                                                              // 40
  return target;                                                                                // 41
};                                                                                              // 42
                                                                                                // 43
/**                                                                                             // 44
 * Returns a function that returns the translation                                              // 45
 * Useful for autoform                                                                          // 46
 */                                                                                             // 47
orion.helpers.getTranslation = function(key) {                                                  // 48
  return function() {                                                                           // 49
    return i18n(key);                                                                           // 50
  };                                                                                            // 51
};                                                                                              // 52
                                                                                                // 53
//////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                              //
// packages/orionjs_base/home-route.js                                                          //
//                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                //
/**                                                                                             // 1
 * Set the admin home route                                                                     // 2
 */                                                                                             // 3
Options.init('adminHomeRoute', 'myAccount.index');                                              // 4
                                                                                                // 5
if (RouterLayer.router == 'iron-router') {                                                      // 6
  RouterLayer.ironRouter.route('/admin', function () {                                          // 7
    this.router.go(Options.get('adminHomeRoute'), {}, { replaceState: true });                  // 8
  }, { name: 'admin' });                                                                        // 9
} else {                                                                                        // 10
  RouterLayer.flowRouter.route('/admin', {                                                      // 11
    name: 'admin',                                                                              // 12
    action: function() {                                                                        // 13
      RouterLayer.go(Options.get('adminHomeRoute'));                                            // 14
    }                                                                                           // 15
  });                                                                                           // 16
}                                                                                               // 17
                                                                                                // 18
//////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                              //
// packages/orionjs_base/layouts.js                                                             //
//                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                //
/**                                                                                             // 1
 * Requests a layout template                                                                   // 2
 */                                                                                             // 3
ReactiveTemplates.request('layout');                                                            // 4
                                                                                                // 5
/**                                                                                             // 6
 * Requests a layout for auth                                                                   // 7
 */                                                                                             // 8
ReactiveTemplates.request('outAdminLayout');                                                    // 9
                                                                                                // 10
//////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:base'] = {
  orion: orion
};

})();

//# sourceMappingURL=orionjs_base.js.map
