(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:attributes'].orion;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/orionjs_relationships/attribute.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var getSchema = function(options, hasMany) {                                                                         // 1
  check(options, Match.ObjectIncluding({                                                                             // 2
    titleField: Match.OneOf(String, Array),                                                                          // 3
    publicationName: String,                                                                                         // 4
    customPublication: Match.Optional(Boolean),                                                                      // 5
    pluralName: Match.Optional(Match.OneOf(String, Function)),                                                       // 6
    singularName: Match.Optional(Match.OneOf(String, Function)),                                                     // 7
    collection: Mongo.Collection,                                                                                    // 8
    filter: Match.Optional(Function),                                                                                // 9
    createFilter: Match.Optional(Function),                                                                          // 10
    create: Match.Optional(Function),                                                                                // 11
    additionalFields: Match.Optional(Array),                                                                         // 12
    sortFields: Match.Optional(Match.OneOf(Array, Object)),                                                          // 13
    render: Match.Optional({                                                                                         // 14
      item: Function,                                                                                                // 15
      option: Function                                                                                               // 16
    })                                                                                                               // 17
  }));                                                                                                               // 18
                                                                                                                     // 19
  if (!options.filter) {                                                                                             // 20
    options.filter = function(userId) {                                                                              // 21
      return {};                                                                                                     // 22
    };                                                                                                               // 23
  }                                                                                                                  // 24
                                                                                                                     // 25
  if (!options.create) {                                                                                             // 26
    options.create = false;                                                                                          // 27
  }                                                                                                                  // 28
                                                                                                                     // 29
  if (_.isArray(options.titleField) && options.titleField.length === 1) {                                            // 30
    options.titleField = options.titleField[0];                                                                      // 31
  }                                                                                                                  // 32
                                                                                                                     // 33
  function render_item_default(item, escape) {                                                                       // 34
    var fieldContent = "";                                                                                           // 35
    if (_.isArray(options.titleField)) {                                                                             // 36
      _.each(options.titleField, function(field, index) { fieldContent += (index > 0 ? " | " : "") + escape(item[field]); } );
    }                                                                                                                // 38
    else {                                                                                                           // 39
      fieldContent = escape(item[options.titleField]);                                                               // 40
    }                                                                                                                // 41
    return '<div>' + fieldContent + '</div>';                                                                        // 42
  }                                                                                                                  // 43
                                                                                                                     // 44
  if (!options.render) {                                                                                             // 45
    options.render = {                                                                                               // 46
      item: function(item, escape) {                                                                                 // 47
        return render_item_default(item, escape);                                                                    // 48
      },                                                                                                             // 49
      option: function(item, escape) {                                                                               // 50
        return render_item_default(item, escape);                                                                    // 51
      }                                                                                                              // 52
    };                                                                                                               // 53
  }                                                                                                                  // 54
                                                                                                                     // 55
  if (!options.additionalFields) {                                                                                   // 56
    options.additionalFields = [];                                                                                   // 57
  }                                                                                                                  // 58
                                                                                                                     // 59
  if (!options.pluralName) {                                                                                         // 60
    options.pluralName = i18n('collections.common.defaultPluralName');                                               // 61
  }                                                                                                                  // 62
                                                                                                                     // 63
  if (!options.singularName) {                                                                                       // 64
    options.singularName = i18n('collections.common.defaultSingularName');                                           // 65
  }                                                                                                                  // 66
                                                                                                                     // 67
  options.fields = _.union(options.additionalFields, options.titleField);                                            // 68
                                                                                                                     // 69
  if (Meteor.isServer) {                                                                                             // 70
    if (!options.customPublication) {                                                                                // 71
      Meteor.publish(options.publicationName, function () {                                                          // 72
        var pubFields = {};                                                                                          // 73
        for (var i = 0; i < options.fields.length; i++) {                                                            // 74
          pubFields[options.fields[i]] = 1;                                                                          // 75
        }                                                                                                            // 76
        return options.collection.find(options.filter(this.userId), { fields: pubFields });                          // 77
      }, { is_auto: true });                                                                                         // 78
    }                                                                                                                // 79
    if (!hasMany) {                                                                                                  // 80
      Meteor.publish(options.publicationName + '_row', function (id) {                                               // 81
        var pubFields = {};                                                                                          // 82
        for (var i = 0; i < options.fields.length; i++) {                                                            // 83
          pubFields[options.fields[i]] = 1;                                                                          // 84
        }                                                                                                            // 85
        var filter = options.filter(this.userId);                                                                    // 86
        filter._id = id;                                                                                             // 87
        return options.collection.find(filter, { fields: pubFields });                                               // 88
      }, { is_auto: true });                                                                                         // 89
    }                                                                                                                // 90
  }                                                                                                                  // 91
                                                                                                                     // 92
  if (hasMany) {                                                                                                     // 93
    return {                                                                                                         // 94
      type: [String],                                                                                                // 95
      orion: options,                                                                                                // 96
      custom: function() {                                                                                           // 97
        if (this.isSet && _.isArray(this.value)) {                                                                   // 98
          var count = options.collection.find({ $and: [{ _id: { $in: this.value } }, options.filter(this.userId)] }).count();
          if (count != this.value.length) {                                                                          // 100
            return 'notAllowed';                                                                                     // 101
          }                                                                                                          // 102
        }                                                                                                            // 103
      }                                                                                                              // 104
    };                                                                                                               // 105
  } else {                                                                                                           // 106
    return {                                                                                                         // 107
      type: String,                                                                                                  // 108
      orion: options,                                                                                                // 109
      custom: function() {                                                                                           // 110
        if (this.isSet && _.isString(this.value)) {                                                                  // 111
          var count = options.collection.find({ $and: [{ _id: this.value }, options.filter(this.userId)] }).count();
          if (count != 1) {                                                                                          // 113
            return 'notAllowed';                                                                                     // 114
          }                                                                                                          // 115
        }                                                                                                            // 116
      }                                                                                                              // 117
    };                                                                                                               // 118
  }                                                                                                                  // 119
};                                                                                                                   // 120
                                                                                                                     // 121
orion.attributes.registerAttribute('hasMany', {                                                                      // 122
  template: 'orionAttributesHasMany',                                                                                // 123
  previewTemplate: 'orionAttributesHasManyColumn',                                                                   // 124
  getSchema: function(options) {                                                                                     // 125
    return getSchema(options, true);                                                                                 // 126
  },                                                                                                                 // 127
  valueOut: function() {                                                                                             // 128
    return this.val();                                                                                               // 129
  }                                                                                                                  // 130
});                                                                                                                  // 131
                                                                                                                     // 132
orion.attributes.registerAttribute('hasOne', {                                                                       // 133
  template: 'orionAttributesHasOne',                                                                                 // 134
  previewTemplate: 'orionAttributesHasOneColumn',                                                                    // 135
  getSchema: function(options) {                                                                                     // 136
    return getSchema(options, false);                                                                                // 137
  },                                                                                                                 // 138
  valueOut: function() {                                                                                             // 139
    return this.val();                                                                                               // 140
  }                                                                                                                  // 141
});                                                                                                                  // 142
                                                                                                                     // 143
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/orionjs_relationships/users.js                                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
orion.attributes.registerAttribute('users', {                                                                        // 1
  template: 'orionAttributesHasMany',                                                                                // 2
  previewTemplate: 'orionAttributesHasManyColumn',                                                                   // 3
  getSchema: function(options) {                                                                                     // 4
    options = _.extend(options, {                                                                                    // 5
      titleField: 'profile.name',                                                                                    // 6
      pluralName: i18n('attributes.users.pluralName'),                                                               // 7
      singularName: i18n('attributes.users.singularName'),                                                           // 8
      collection: Meteor.users,                                                                                      // 9
      additionalFields: ['emails.address'],                                                                          // 10
      render: {                                                                                                      // 11
        item: function(item, escape) {                                                                               // 12
          return '<div class="usersAttribute">' +                                                                    // 13
            (item['profile.name'] ? '<span class="name">' + escape(item['profile.name']) + '</span>' : '') +         // 14
            (item['emails.address'] ? '<span class="email">' + escape(item['emails.address']) + '</span>' : '') +    // 15
          '</div>';                                                                                                  // 16
        },                                                                                                           // 17
        option: function(item, escape) {                                                                             // 18
          var label = item['profile.name'] || item['emails.address'];                                                // 19
          var caption = item['profile.name'] ? item['emails.address'] : null;                                        // 20
          return '<div class="usersAttribute">' +                                                                    // 21
            '<span class="name">' + escape(label) + '</span>' +                                                      // 22
            (caption ? '<span class="email">' + escape(caption) + '</span>' : '') +                                  // 23
          '</div>';                                                                                                  // 24
        }                                                                                                            // 25
      },                                                                                                             // 26
    });                                                                                                              // 27
    return orion.attribute('hasMany', {}, options);                                                                  // 28
  },                                                                                                                 // 29
  valueOut: function() {                                                                                             // 30
    return this.val();                                                                                               // 31
  }                                                                                                                  // 32
});                                                                                                                  // 33
                                                                                                                     // 34
orion.attributes.registerAttribute('user', {                                                                         // 35
  template: 'orionAttributesHasOne',                                                                                 // 36
  previewTemplate: 'orionAttributesHasOneColumn',                                                                    // 37
  getSchema: function(options) {                                                                                     // 38
    options = _.extend(options, {                                                                                    // 39
      titleField: 'profile.name',                                                                                    // 40
      collection: Meteor.users,                                                                                      // 41
      additionalFields: ['emails.address'],                                                                          // 42
      render: {                                                                                                      // 43
        item: function(item, escape) {                                                                               // 44
          return '<div class="usersAttribute">' +                                                                    // 45
            (item['profile.name'] ? '<span class="name">' + escape(item['profile.name']) + '</span>' : '') +         // 46
            (item['emails.address'] ? '<span class="email">' + escape(item['emails.address']) + '</span>' : '') +    // 47
          '</div>';                                                                                                  // 48
        },                                                                                                           // 49
        option: function(item, escape) {                                                                             // 50
          var label = item['profile.name'] || item['emails.address'];                                                // 51
          var caption = item['profile.name'] ? item['emails.address'] : null;                                        // 52
          return '<div class="usersAttribute">' +                                                                    // 53
            '<span class="name">' + escape(label) + '</span>' +                                                      // 54
            (caption ? '<span class="email">' + escape(caption) + '</span>' : '') +                                  // 55
          '</div>';                                                                                                  // 56
        }                                                                                                            // 57
      },                                                                                                             // 58
    });                                                                                                              // 59
    return orion.attribute('hasOne', {}, options);                                                                   // 60
  },                                                                                                                 // 61
  valueOut: function() {                                                                                             // 62
    return this.val();                                                                                               // 63
  }                                                                                                                  // 64
});                                                                                                                  // 65
                                                                                                                     // 66
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:relationships'] = {};

})();

//# sourceMappingURL=orionjs_relationships.js.map
