(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/oliver_phantomjs-shim/packages/oliver_phantomjs-shim.js                                           //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
(function () {                                                                                                // 1
                                                                                                              // 2
//////////////////////////////////////////////////////////////////////////////////////////////////////////    // 3
//                                                                                                      //    // 4
// packages/oliver:phantomjs-shim/phantomjs-shim.js                                                     //    // 5
//                                                                                                      //    // 6
//////////////////////////////////////////////////////////////////////////////////////////////////////////    // 7
                                                                                                        //    // 8
/**                                                                                                     // 1  // 9
 * MDN bind polyfill.                                                                                   // 2  // 10
 *                                                                                                      // 3  // 11
 * https://developer.mozilla.org/en/docs/Web/JavaScript/Reference/Global_objects/Function/bind#Polyfill // 4  // 12
 */                                                                                                     // 5  // 13
if (!Function.prototype.bind) {                                                                         // 6  // 14
  Function.prototype.bind = function(oThis) {                                                           // 7  // 15
    if (typeof this !== 'function') {                                                                   // 8  // 16
      // closest thing possible to the ECMAScript 5 internal IsCallable function                        // 9  // 17
      throw new TypeError('Function.prototype.bind - what is trying to be bound is not callable');      // 10
    }                                                                                                   // 11
                                                                                                        // 12
    var aArgs   = Array.prototype.slice.call(arguments, 1),                                             // 13
        fToBind = this,                                                                                 // 14
        fNOP    = function() {},                                                                        // 15
        fBound  = function() {                                                                          // 16
          return fToBind.apply(this instanceof fNOP                                                     // 17
                  ? this                                                                                // 18
                  : oThis,                                                                              // 19
              aArgs.concat(Array.prototype.slice.call(arguments)));                                     // 20
        };                                                                                              // 21
                                                                                                        // 22
    fNOP.prototype = this.prototype;                                                                    // 23
    fBound.prototype = new fNOP();                                                                      // 24
                                                                                                        // 25
    return fBound;                                                                                      // 26
  };                                                                                                    // 27
}                                                                                                       // 28
                                                                                                        // 29
//////////////////////////////////////////////////////////////////////////////////////////////////////////    // 38
                                                                                                              // 39
}).call(this);                                                                                                // 40
                                                                                                              // 41
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['oliver:phantomjs-shim'] = {};

})();

//# sourceMappingURL=oliver_phantomjs-shim.js.map
