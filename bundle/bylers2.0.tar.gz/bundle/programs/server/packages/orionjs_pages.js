(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:base'].orion;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var HTML = Package.htmljs.HTML;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Autoupdate = Package.autoupdate.Autoupdate;

(function(){

/////////////////////////////////////////////////////////////////////////////////////
//                                                                                 //
// packages/orionjs_pages/pages.js                                                 //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
                                                                                   //
orion.pages = {                                                                    // 1
  templates: {},                                                                   // 2
  collection: new Meteor.Collection('pages'),                                      // 3
};                                                                                 // 4
                                                                                   // 5
Roles.registerAction('pages.index', true);                                         // 6
Roles.registerAction('pages.insert', true);                                        // 7
Roles.registerAction('pages.update', true);                                        // 8
Roles.registerAction('pages.remove', true);                                        // 9
                                                                                   // 10
orion.pages.collection.attachRoles('pages');                                       // 11
                                                                                   // 12
orion.pages.collection.helpers({                                                   // 13
  path: function () {                                                              // 14
    return RouterLayer.pathFor('page', { url: this.url });                         // 15
  }                                                                                // 16
});                                                                                // 17
                                                                                   // 18
/**                                                                                // 19
 * Create a new template                                                           // 20
 */                                                                                // 21
orion.pages.addTemplate = function (options, schema) {                             // 22
  if (!options.template) {                                                         // 23
    throw new Meteor.Error('orion', 'Template is required');                       // 24
  }                                                                                // 25
                                                                                   // 26
  var newTemplate = _.extend({                                                     // 27
    name: options.template,                                                        // 28
    description: 'No description'                                                  // 29
  }, options);                                                                     // 30
                                                                                   // 31
  var newSchema = orion.pages.getNewTemplateSchema(schema, newTemplate);           // 32
  newTemplate.schema = new SimpleSchema(newSchema);                                // 33
                                                                                   // 34
  orion.pages.templates[newTemplate.template] = newTemplate;                       // 35
                                                                                   // 36
  return newTemplate;                                                              // 37
};                                                                                 // 38
                                                                                   // 39
orion.pages.getNewTemplateSchema = function (schema, newTemplate) {                // 40
  return _.extend({                                                                // 41
    title: {                                                                       // 42
      type: String,                                                                // 43
      label: orion.helpers.getTranslation('pages.schema.title')                    // 44
    },                                                                             // 45
    url: {                                                                         // 46
      type: String,                                                                // 47
      regEx: /^[a-z0-9A-Z_-]+$/,                                                   // 48
      label: orion.helpers.getTranslation('pages.schema.url')                      // 49
    },                                                                             // 50
    template: {                                                                    // 51
      type: String,                                                                // 52
      autoform: {                                                                  // 53
        omit: true                                                                 // 54
      },                                                                           // 55
      autoValue: function () {                                                     // 56
        return newTemplate.template;                                               // 57
      }                                                                            // 58
    },                                                                             // 59
    createdAt: orion.attribute('createdAt'),                                       // 60
    updatedAt: orion.attribute('updatedAt'),                                       // 61
    createdBy: orion.attribute('createdBy')                                        // 62
  }, schema);                                                                      // 63
};                                                                                 // 64
                                                                                   // 65
var Tabular = null;                                                                // 66
                                                                                   // 67
if (Package['nicolaslopezj:tabular-materialize']) {                                // 68
  Tabular = Package['nicolaslopezj:tabular-materialize'].Tabular;                  // 69
}                                                                                  // 70
                                                                                   // 71
if (Package['aldeed:tabular']) {                                                   // 72
  Tabular = Package['aldeed:tabular'].Tabular;                                     // 73
}                                                                                  // 74
                                                                                   // 75
if (!Tabular) {                                                                    // 76
  throw new Meteor.Error('orion', 'You must install tabular to use this package');
}                                                                                  // 78
                                                                                   // 79
orion.pages.tabular = new Tabular.Table({                                          // 80
  name: 'PagesIndex',                                                              // 81
  collection: orion.pages.collection,                                              // 82
  columns: [                                                                       // 83
    { data: 'title', title: i18n('pages.schema.title') },                          // 84
    { data: 'url', title: i18n('pages.schema.url'), render: function(val, type, doc) { return '<a href="' + RouterLayer.pathFor('page', doc) + '">' + RouterLayer.pathFor('page', doc) + '</a>'; } }
  ]                                                                                // 86
});                                                                                // 87
                                                                                   // 88
/**                                                                                // 89
 * Wait the initialization of flow router                                          // 90
 */                                                                                // 91
 if (RouterLayer.router == 'flow-router') {                                        // 92
   RouterLayer.flowRouter.wait();                                                  // 93
 }                                                                                 // 94
                                                                                   // 95
/**                                                                                // 96
 * Register page routes on meteor startup                                          // 97
 */                                                                                // 98
Meteor.startup(function(){                                                         // 99
  RouterLayer.route('/:url', {                                                     // 100
    name: 'page',                                                                  // 101
    template: 'orionPages_mainTemplate'                                            // 102
  });                                                                              // 103
                                                                                   // 104
  if (RouterLayer.router == 'flow-router') {                                       // 105
    RouterLayer.flowRouter.initialize();                                           // 106
  }                                                                                // 107
});                                                                                // 108
                                                                                   // 109
/////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////
//                                                                                 //
// packages/orionjs_pages/admin.js                                                 //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
                                                                                   //
/**                                                                                // 1
 * Register the Page admin routes and add protection                               // 2
 */                                                                                // 3
ReactiveTemplates.request('pages.index');                                          // 4
RouterLayer.route('/admin/pages', {                                                // 5
  layout: 'layout',                                                                // 6
  template: 'pages.index',                                                         // 7
  name: 'pages.index',                                                             // 8
  reactiveTemplates: true                                                          // 9
});                                                                                // 10
orion.accounts.addProtectedRoute('pages.index');                                   // 11
                                                                                   // 12
ReactiveTemplates.request('pages.create');                                         // 13
RouterLayer.route('/admin/pages/create', {                                         // 14
  layout: 'layout',                                                                // 15
  template: 'pages.create',                                                        // 16
  name: 'pages.create',                                                            // 17
  reactiveTemplates: true                                                          // 18
});                                                                                // 19
orion.accounts.addProtectedRoute('pages.create');                                  // 20
                                                                                   // 21
ReactiveTemplates.request('pages.update');                                         // 22
RouterLayer.route('/admin/pages/:_id/edit', {                                      // 23
  layout: 'layout',                                                                // 24
  template: 'pages.update',                                                        // 25
  name: 'pages.update',                                                            // 26
  reactiveTemplates: true                                                          // 27
});                                                                                // 28
orion.accounts.addProtectedRoute('pages.update');                                  // 29
                                                                                   // 30
ReactiveTemplates.request('pages.delete');                                         // 31
RouterLayer.route('/admin/pages/:_id/delete', {                                    // 32
  layout: 'layout',                                                                // 33
  template: 'pages.delete',                                                        // 34
  name: 'pages.delete',                                                            // 35
  reactiveTemplates: true                                                          // 36
});                                                                                // 37
orion.accounts.addProtectedRoute('pages.delete');                                  // 38
                                                                                   // 39
                                                                                   // 40
/**                                                                                // 41
 * Register the Pages link in the admin panel                                      // 42
 */                                                                                // 43
if (Meteor.isClient) {                                                             // 44
  Tracker.autorun(function () {                                                    // 45
    orion.links.add({                                                              // 46
      index: 40,                                                                   // 47
      identifier: 'pages-index',                                                   // 48
      title: i18n('pages.index.title'),                                            // 49
      routeName: 'pages.index',                                                    // 50
      activeRouteRegex: 'pages',                                                   // 51
      permission: 'pages.index',                                                   // 52
    });                                                                            // 53
  });                                                                              // 54
}                                                                                  // 55
                                                                                   // 56
/////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////
//                                                                                 //
// packages/orionjs_pages/pages_server.js                                          //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
                                                                                   //
Meteor.publish('pages', function () {                                              // 1
  return orion.pages.collection.find();                                            // 2
});                                                                                // 3
                                                                                   // 4
Meteor.publish('page', function (url) {                                            // 5
  check(url, String);                                                              // 6
  return orion.pages.collection.find({ url: url });                                // 7
});                                                                                // 8
                                                                                   // 9
Meteor.publish('pageById', function (pageId) {                                     // 10
  check(pageId, String);                                                           // 11
  return orion.pages.collection.find({ _id: pageId });                             // 12
});                                                                                // 13
                                                                                   // 14
Meteor.startup(function() {                                                        // 15
  orion.pages.collection._ensureIndex({ url: 1 }, { unique: 1 });                  // 16
});                                                                                // 17
                                                                                   // 18
Meteor.methods({                                                                   // 19
  orion_pageWithUrl: function(url) {                                               // 20
    check(url, String);                                                            // 21
    return orion.pages.collection.findOne({ url: url });                           // 22
  }                                                                                // 23
})                                                                                 // 24
                                                                                   // 25
/////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:pages'] = {};

})();

//# sourceMappingURL=orionjs_pages.js.map
