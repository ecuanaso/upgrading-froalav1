(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:base'].orion;
var moment = Package['momentjs:moment'].moment;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var orion;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/orionjs_attributes/attributes.js                                                             //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
/**                                                                                                      // 1
 * Adds the option the set orionAttribute on SimpleSchema                                                // 2
 */                                                                                                      // 3
SimpleSchema.extendOptions({                                                                             // 4
  orionAttribute: Match.Optional(String),                                                                // 5
  orion: Match.Optional(Object)                                                                          // 6
});                                                                                                      // 7
                                                                                                         // 8
/**                                                                                                      // 9
 * Definition of the attributes object                                                                   // 10
 */                                                                                                      // 11
orion.attributes = {};                                                                                   // 12
                                                                                                         // 13
/**                                                                                                      // 14
 * Returns the schema for the attribute                                                                  // 15
 */                                                                                                      // 16
orion.attribute = function(name, schema, options) {                                                      // 17
  if (!_.has(orion.attributes, name)) {                                                                  // 18
    throw 'The attribute "' + name + '" does not exist';                                                 // 19
  }                                                                                                      // 20
  var schema = schema || {};                                                                             // 21
  var options = options || {};                                                                           // 22
  var attributeSchema = orion.attributes[name].getSchema.call(this, options);                            // 23
  var override = {                                                                                       // 24
    orionAttribute: name,                                                                                // 25
    autoform: {                                                                                          // 26
      type: 'orion.' + name                                                                              // 27
    }                                                                                                    // 28
  }                                                                                                      // 29
  var attribute = orion.helpers.deepExtend(orion.helpers.deepExtend(schema, attributeSchema), override);
  return attribute;                                                                                      // 31
}                                                                                                        // 32
                                                                                                         // 33
/**                                                                                                      // 34
 * Returns proper tabular column for the attribute                                                       // 35
 */                                                                                                      // 36
orion.attributeColumn = function(name, key, title) {                                                     // 37
  return {                                                                                               // 38
    data: key,                                                                                           // 39
    title: title,                                                                                        // 40
    defaultContent: '',                                                                                  // 41
    orderable: false,                                                                                    // 42
    render: function() {                                                                                 // 43
      return '';                                                                                         // 44
    },                                                                                                   // 45
    createdCell: function(cell, cellData, rowData) {                                                     // 46
      var collection = rowData._collection();                                                            // 47
      var schema = rowData._collection().simpleSchema()._schema[key];                                    // 48
      var data = {                                                                                       // 49
        key: key,                                                                                        // 50
        value: cellData,                                                                                 // 51
        item: rowData,                                                                                   // 52
        collection: collection,                                                                          // 53
        schema: schema,                                                                                  // 54
      }                                                                                                  // 55
      var template = ReactiveTemplates.get('attributePreview.' + name);                                  // 56
      Blaze.renderWithData(Template[template], data, cell);                                              // 57
    }                                                                                                    // 58
  }                                                                                                      // 59
}                                                                                                        // 60
                                                                                                         // 61
/**                                                                                                      // 62
 * Helper function to use arrays of attributes (Ex: array of images)                                     // 63
 */                                                                                                      // 64
orion.arrayOfAttribute = function(name, schema, options) {                                               // 65
  var subSchema = new SimpleSchema({                                                                     // 66
    item: orion.attribute(name, {                                                                        // 67
      autoform: {                                                                                        // 68
        label: false                                                                                     // 69
      }                                                                                                  // 70
    })                                                                                                   // 71
  });                                                                                                    // 72
  return orion.helpers.deepExtend(schema, {                                                              // 73
    type: [subSchema]                                                                                    // 74
  });                                                                                                    // 75
}                                                                                                        // 76
                                                                                                         // 77
/**                                                                                                      // 78
 * Creates a new attribute                                                                               // 79
 */                                                                                                      // 80
orion.attributes.registerAttribute = function(name, attribute) {                                         // 81
  check(name, String);                                                                                   // 82
  check(attribute, {                                                                                     // 83
    template: Match.Optional(String),                                                                    // 84
    columnTemplate: Match.Optional(String),                                                              // 85
    previewTemplate: Match.Optional(String),                                                             // 86
    getSchema: Function,                                                                                 // 87
    valueOut: Match.Optional(Function),                                                                  // 88
    valueIn: Match.Optional(Function),                                                                   // 89
    valueConverters: Match.Optional(Function),                                                           // 90
    contextAdjust: Match.Optional(Function),                                                             // 91
  });                                                                                                    // 92
                                                                                                         // 93
  if (attribute.template) {                                                                              // 94
    ReactiveTemplates.request('attribute.' + name, attribute.template);                                  // 95
  }                                                                                                      // 96
                                                                                                         // 97
  if (attribute.previewTemplate) {                                                                       // 98
    ReactiveTemplates.request('attributePreview.' + name, attribute.previewTemplate);                    // 99
  }                                                                                                      // 100
                                                                                                         // 101
  orion.attributes[name] = attribute;                                                                    // 102
                                                                                                         // 103
  if (Meteor.isClient && attribute.template) {                                                           // 104
    Tracker.autorun(function () {                                                                        // 105
      AutoForm.addInputType('orion.' + name, {                                                           // 106
        template: ReactiveTemplates.get('attribute.' + name),                                            // 107
        valueIn: attribute.valueIn,                                                                      // 108
        valueOut: attribute.valueOut,                                                                    // 109
        valueConverters: attribute.valueConverters,                                                      // 110
        contextAdjust: attribute.contextAdjust                                                           // 111
      });                                                                                                // 112
    });                                                                                                  // 113
  }                                                                                                      // 114
}                                                                                                        // 115
                                                                                                         // 116
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/orionjs_attributes/created-by/created-by.js                                                  //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
orion.attributes.registerAttribute('createdBy', {                                                        // 1
  previewTemplate: 'createdByPreview',                                                                   // 2
  getSchema: function(options) {                                                                         // 3
    return {                                                                                             // 4
      type: String,                                                                                      // 5
      autoform: {                                                                                        // 6
        omit: true                                                                                       // 7
      },                                                                                                 // 8
      optional: true,                                                                                    // 9
      autoValue: function() {                                                                            // 10
        if (this.isInsert) {                                                                             // 11
          return this.userId;                                                                            // 12
        } else if (this.isUpsert) {                                                                      // 13
          return { $setOnInsert: this.userId };                                                          // 14
        } else {                                                                                         // 15
          this.unset();                                                                                  // 16
        }                                                                                                // 17
      }                                                                                                  // 18
    };                                                                                                   // 19
  }                                                                                                      // 20
});                                                                                                      // 21
                                                                                                         // 22
if (Meteor.isServer) {                                                                                   // 23
  Meteor.publish('userProfileForCreatedByAttributeColumn', function(userId) {                            // 24
    check(userId, String);                                                                               // 25
    return Meteor.users.find({ _id: userId }, { fields: { profile: 1 } });                               // 26
  });                                                                                                    // 27
}                                                                                                        // 28
if (Meteor.isClient) {                                                                                   // 29
  ReactiveTemplates.onRendered('attributePreview.createdBy', function() {                                // 30
    this.subscribe('userProfileForCreatedByAttributeColumn', this.data.value)                            // 31
  });                                                                                                    // 32
  ReactiveTemplates.helpers('attributePreview.createdBy', {                                              // 33
    name: function() {                                                                                   // 34
      var user = Meteor.users.findOne(this.value)                                                        // 35
      return user && user.profile.name;                                                                  // 36
    }                                                                                                    // 37
  });                                                                                                    // 38
}                                                                                                        // 39
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/orionjs_attributes/updated-at/updated-at.js                                                  //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
orion.attributes.registerAttribute('updatedAt', {                                                        // 1
  previewTemplate: 'updatedAtPreview',                                                                   // 2
  getSchema: function(options) {                                                                         // 3
    return {                                                                                             // 4
      type: Date,                                                                                        // 5
      autoform: {                                                                                        // 6
        omit: true                                                                                       // 7
      },                                                                                                 // 8
      autoValue: function() {                                                                            // 9
        if (this.isUpdate || this.isInsert) {                                                            // 10
          return new Date;                                                                               // 11
        } else if (this.isUpsert) {                                                                      // 12
          return {$setOnInsert: new Date};                                                               // 13
        } else {                                                                                         // 14
          this.unset();                                                                                  // 15
        }                                                                                                // 16
      }                                                                                                  // 17
    };                                                                                                   // 18
  }                                                                                                      // 19
});                                                                                                      // 20
                                                                                                         // 21
if (Meteor.isClient) {                                                                                   // 22
  ReactiveTemplates.helpers('attributePreview.updatedAt', {                                              // 23
    date: function() {                                                                                   // 24
      return this.value && moment(this.value).format('LLL');                                             // 25
    }                                                                                                    // 26
  });                                                                                                    // 27
}                                                                                                        // 28
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/orionjs_attributes/created-at/created-at.js                                                  //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
orion.attributes.registerAttribute('createdAt', {                                                        // 1
  previewTemplate: 'createdAtPreview',                                                                   // 2
  getSchema: function(options) {                                                                         // 3
    return {                                                                                             // 4
      type: Date,                                                                                        // 5
      autoform: {                                                                                        // 6
        omit: true                                                                                       // 7
      },                                                                                                 // 8
      autoValue: function() {                                                                            // 9
        if (this.isInsert) {                                                                             // 10
          return new Date;                                                                               // 11
        } else if (this.isUpsert) {                                                                      // 12
          return {$setOnInsert: new Date};                                                               // 13
        } else {                                                                                         // 14
          this.unset();                                                                                  // 15
        }                                                                                                // 16
      }                                                                                                  // 17
    };                                                                                                   // 18
  }                                                                                                      // 19
});                                                                                                      // 20
                                                                                                         // 21
if (Meteor.isClient) {                                                                                   // 22
  ReactiveTemplates.helpers('attributePreview.createdAt', {                                              // 23
    date: function() {                                                                                   // 24
      return this.value && moment(this.value).format('LLL');                                             // 25
    }                                                                                                    // 26
  });                                                                                                    // 27
}                                                                                                        // 28
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:attributes'] = {
  orion: orion
};

})();

//# sourceMappingURL=orionjs_attributes.js.map
