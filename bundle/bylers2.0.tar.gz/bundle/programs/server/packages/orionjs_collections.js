(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:base'].orion;
var _ = Package.underscore._;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var orion;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/orionjs_collections/init.js                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Init the entities variable                                                                                         // 2
 */                                                                                                                   // 3
orion.collections = {};                                                                                               // 4
                                                                                                                      // 5
orion.collections.hooks = {                                                                                           // 6
  onCreated: [],                                                                                                      // 7
};                                                                                                                    // 8
                                                                                                                      // 9
orion.collections.onCreated = function(cb) {                                                                          // 10
  this.hooks.onCreated.push(cb);                                                                                      // 11
};                                                                                                                    // 12
                                                                                                                      // 13
/**                                                                                                                   // 14
 * Request the default templates using options                                                                        // 15
 */                                                                                                                   // 16
Options.init('collectionsDefaultIndexTemplate');                                                                      // 17
Options.init('collectionsDefaultCreateTemplate');                                                                     // 18
Options.init('collectionsDefaultUpdateTemplate');                                                                     // 19
Options.init('collectionsDefaultDeleteTemplate');                                                                     // 20
                                                                                                                      // 21
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/orionjs_collections/new.js                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
orion.collections.list = {};                                                                                          // 1
                                                                                                                      // 2
/**                                                                                                                   // 3
 * Collection definition, it overrides Mongo.Collection                                                               // 4
 */                                                                                                                   // 5
orion.collection = function(name, options) {                                                                          // 6
  check(name, String);                                                                                                // 7
  check(options, Object);                                                                                             // 8
                                                                                                                      // 9
  var collection = new Mongo.Collection(name, options);                                                               // 10
                                                                                                                      // 11
  options = _.extend({                                                                                                // 12
    name: name,                                                                                                       // 13
    routePath: name,                                                                                                  // 14
    pluralName: name,                                                                                                 // 15
    singularName: name,                                                                                               // 16
    title: name[0].toUpperCase() + name.slice(1),                                                                     // 17
  }, options);                                                                                                        // 18
                                                                                                                      // 19
  collection = _.extend(collection, options);                                                                         // 20
                                                                                                                      // 21
  for (var i = 0, N = orion.collections.hooks.onCreated.length; i < N; i++) {                                         // 22
    orion.collections.hooks.onCreated[i].call(collection);                                                            // 23
  }                                                                                                                   // 24
                                                                                                                      // 25
  collection.helpers({                                                                                                // 26
    _collection: function() {                                                                                         // 27
      return collection;                                                                                              // 28
    }                                                                                                                 // 29
  });                                                                                                                 // 30
                                                                                                                      // 31
  orion.collections.list[name] = collection;                                                                          // 32
  return collection;                                                                                                  // 33
};                                                                                                                    // 34
                                                                                                                      // 35
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/orionjs_collections/permissions.js                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
orion.collections.onCreated(function() {                                                                              // 1
  var self = this;                                                                                                    // 2
                                                                                                                      // 3
  /**                                                                                                                 // 4
   * Collection permissions                                                                                           // 5
   */                                                                                                                 // 6
  Roles.registerAction('collections.' + this.name + '.index', true);                                                  // 7
  Roles.registerAction('collections.' + this.name + '.showCreate', true);                                             // 8
  Roles.registerAction('collections.' + this.name + '.showUpdate', true);                                             // 9
  Roles.registerAction('collections.' + this.name + '.showRemove', true);                                             // 10
  Roles.registerHelper('collections.' + this.name + '.indexFilter', {});                                              // 11
                                                                                                                      // 12
  this.attachRoles('collections.' + this.name);                                                                       // 13
                                                                                                                      // 14
  if (Meteor.isClient) {                                                                                              // 15
    this.canIndex = function() {                                                                                      // 16
      return Roles.userHasPermission(Meteor.userId(), 'collections.' + self.name + '.index');                         // 17
    };                                                                                                                // 18
    this.canShowCreate = function() {                                                                                 // 19
      return Roles.userHasPermission(Meteor.userId(), 'collections.' + self.name + '.showCreate');                    // 20
    };                                                                                                                // 21
    this.getHiddenFields = function() {                                                                               // 22
      var docId = RouterLayer.getParam('_id');                                                                        // 23
      return _.union.apply(this, Roles.helper(Meteor.userId(), 'collections.' + self.name + '.forbiddenFields', docId));
    };                                                                                                                // 25
    this.helpers({                                                                                                    // 26
      canShowUpdate: function () {                                                                                    // 27
        return Roles.userHasPermission(Meteor.userId(), 'collections.' + self.name + '.showUpdate', this);            // 28
      },                                                                                                              // 29
      canShowRemove: function() {                                                                                     // 30
        return Roles.userHasPermission(Meteor.userId(), 'collections.' + self.name + '.showRemove', this);            // 31
      }                                                                                                               // 32
    });                                                                                                               // 33
  }                                                                                                                   // 34
});                                                                                                                   // 35
                                                                                                                      // 36
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/orionjs_collections/admin.js                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
orion.collections.onCreated(function() {                                                                              // 1
  var self = this;                                                                                                    // 2
                                                                                                                      // 3
  /**                                                                                                                 // 4
   * Request a template for the collection                                                                            // 5
   */                                                                                                                 // 6
  ReactiveTemplates.request('collections.' + self.name + '.index', Options.get('collectionsDefaultIndexTemplate'));   // 7
                                                                                                                      // 8
  /**                                                                                                                 // 9
   * Register the index route                                                                                         // 10
   */                                                                                                                 // 11
  RouterLayer.route('/admin/' + self.routePath, {                                                                     // 12
    layout: 'layout',                                                                                                 // 13
    template: 'collections.' + self.name + '.index',                                                                  // 14
    name: 'collections.' + self.name + '.index',                                                                      // 15
    reactiveTemplates: true                                                                                           // 16
  });                                                                                                                 // 17
  self.indexPath = function() {                                                                                       // 18
    return RouterLayer.pathFor('collections.' + self.name + '.index');                                                // 19
  };                                                                                                                  // 20
                                                                                                                      // 21
  /**                                                                                                                 // 22
   * Ensure user is logged in                                                                                         // 23
   */                                                                                                                 // 24
  orion.accounts.addProtectedRoute('collections.' + self.name + '.index');                                            // 25
                                                                                                                      // 26
  /**                                                                                                                 // 27
   * Request a template for the collection create                                                                     // 28
   */                                                                                                                 // 29
  ReactiveTemplates.request('collections.' + self.name + '.create', Options.get('collectionsDefaultCreateTemplate'));
                                                                                                                      // 31
  /**                                                                                                                 // 32
   * Register the create route                                                                                        // 33
   */                                                                                                                 // 34
  RouterLayer.route('/admin/' + self.routePath + '/create', {                                                         // 35
    layout: 'layout',                                                                                                 // 36
    template: 'collections.' + self.name + '.create',                                                                 // 37
    name: 'collections.' + self.name + '.create',                                                                     // 38
    reactiveTemplates: true                                                                                           // 39
  });                                                                                                                 // 40
  self.createPath = function() {                                                                                      // 41
    return RouterLayer.pathFor('collections.' + self.name + '.create');                                               // 42
  };                                                                                                                  // 43
                                                                                                                      // 44
  /**                                                                                                                 // 45
   * Ensure user is logged in                                                                                         // 46
   */                                                                                                                 // 47
  orion.accounts.addProtectedRoute('collections.' + self.name + '.create');                                           // 48
                                                                                                                      // 49
  /**                                                                                                                 // 50
   * Request a template for the collection update                                                                     // 51
   */                                                                                                                 // 52
  ReactiveTemplates.request('collections.' + self.name + '.update', Options.get('collectionsDefaultUpdateTemplate'));
                                                                                                                      // 54
  /**                                                                                                                 // 55
   * Register the update route                                                                                        // 56
   */                                                                                                                 // 57
  RouterLayer.route('/admin/' + self.routePath + '/:_id', {                                                           // 58
    layout: 'layout',                                                                                                 // 59
    template: 'collections.' + self.name + '.update',                                                                 // 60
    name: 'collections.' + self.name + '.update',                                                                     // 61
    reactiveTemplates: true                                                                                           // 62
  });                                                                                                                 // 63
  self.updatePath = function(item) {                                                                                  // 64
    var options = item;                                                                                               // 65
    if (_.isString(item)) {                                                                                           // 66
      options = { _id: item };                                                                                        // 67
    }                                                                                                                 // 68
    return RouterLayer.pathFor('collections.' + self.name + '.update', options);                                      // 69
  };                                                                                                                  // 70
                                                                                                                      // 71
  /**                                                                                                                 // 72
   * Ensure user is logged in                                                                                         // 73
   */                                                                                                                 // 74
  orion.accounts.addProtectedRoute('collections.' + self.name + '.update');                                           // 75
                                                                                                                      // 76
  /**                                                                                                                 // 77
   * Request a template for the collection delete                                                                     // 78
   */                                                                                                                 // 79
  ReactiveTemplates.request('collections.' + self.name + '.delete', Options.get('collectionsDefaultDeleteTemplate'));
                                                                                                                      // 81
  /**                                                                                                                 // 82
   * Register the delete route                                                                                        // 83
   */                                                                                                                 // 84
  RouterLayer.route('/admin/' + self.routePath + '/:_id/delete', {                                                    // 85
    layout: 'layout',                                                                                                 // 86
    template: 'collections.' + self.name + '.delete',                                                                 // 87
    name: 'collections.' + self.name + '.delete',                                                                     // 88
    reactiveTemplates: true                                                                                           // 89
  });                                                                                                                 // 90
  this.deletePath = function(item) {                                                                                  // 91
    var options = item;                                                                                               // 92
    if (_.isString(item)) {                                                                                           // 93
      options = { _id: item };                                                                                        // 94
    }                                                                                                                 // 95
    return RouterLayer.pathFor('collections.' + self.name + '.delete', options);                                      // 96
  };                                                                                                                  // 97
                                                                                                                      // 98
  /**                                                                                                                 // 99
   * Ensure user is logged in                                                                                         // 100
   */                                                                                                                 // 101
  orion.accounts.addProtectedRoute('collections.' + self.name + '.delete');                                           // 102
});                                                                                                                   // 103
                                                                                                                      // 104
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/orionjs_collections/publications.js                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
orion.collections.onCreated(function() {                                                                              // 1
  var self = this;                                                                                                    // 2
  Meteor.publish('adminGetOne.' + this.name, function (_id) {                                                         // 3
    check(_id, String);                                                                                               // 4
    return self.find(_id);                                                                                            // 5
  }, { is_auto: true });                                                                                              // 6
});                                                                                                                   // 7
                                                                                                                      // 8
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:collections'] = {
  orion: orion
};

})();

//# sourceMappingURL=orionjs_collections.js.map
