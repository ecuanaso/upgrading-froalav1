(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;

/* Package-scope variables */
var __coffeescriptShare, Knox, AWS;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/lepozepo_s3/server/startup.coffee.js                                                           //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
                                                                                                           // 2
                                                                                                           //
Knox = Npm.require("knox");                                                                                // 2
                                                                                                           //
AWS = Npm.require("aws-sdk");                                                                              // 2
                                                                                                           //
this.S3 = {                                                                                                // 2
  config: {},                                                                                              // 7
  knox: {},                                                                                                // 7
  aws: {}                                                                                                  // 7
};                                                                                                         //
                                                                                                           //
Meteor.startup(function() {                                                                                // 2
  if (!_.has(S3.config, "key")) {                                                                          // 12
    console.log("S3: AWS key is undefined");                                                               // 13
  }                                                                                                        //
  if (!_.has(S3.config, "secret")) {                                                                       // 15
    console.log("S3: AWS secret is undefined");                                                            // 16
  }                                                                                                        //
  if (!_.has(S3.config, "bucket")) {                                                                       // 18
    console.log("S3: AWS bucket is undefined");                                                            // 19
  }                                                                                                        //
  if (!_.has(S3.config, "bucket") || !_.has(S3.config, "secret") || !_.has(S3.config, "key")) {            // 21
    return;                                                                                                // 22
  }                                                                                                        //
  _.defaults(S3.config, {                                                                                  // 12
    region: "us-east-1"                                                                                    // 25
  });                                                                                                      //
  S3.knox = Knox.createClient(S3.config);                                                                  // 12
  return S3.aws = new AWS.S3({                                                                             //
    accessKeyId: S3.config.key,                                                                            // 29
    secretAccessKey: S3.config.secret,                                                                     // 29
    region: S3.config.region                                                                               // 29
  });                                                                                                      //
});                                                                                                        // 11
                                                                                                           //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/lepozepo_s3/server/sign_request.coffee.js                                                      //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var calculate_signature, crypto;                                                                           // 1
                                                                                                           //
Meteor.methods({                                                                                           // 1
  _s3_sign: function(ops) {                                                                                // 2
    var expiration, key, policy, post_url, signature;                                                      // 3
    if (ops == null) {                                                                                     //
      ops = {};                                                                                            //
    }                                                                                                      //
    this.unblock();                                                                                        // 3
    _.defaults(ops, {                                                                                      // 3
      expiration: 1800000,                                                                                 // 13
      path: "",                                                                                            // 13
      bucket: S3.config.bucket,                                                                            // 13
      acl: "public-read",                                                                                  // 13
      region: S3.config.region                                                                             // 13
    });                                                                                                    //
    if (check) {                                                                                           // 19
      check(ops, {                                                                                         // 20
        expiration: Number,                                                                                // 21
        path: String,                                                                                      // 21
        bucket: String,                                                                                    // 21
        acl: String,                                                                                       // 21
        region: String,                                                                                    // 21
        file_type: String,                                                                                 // 21
        file_name: String,                                                                                 // 21
        file_size: Number                                                                                  // 21
      });                                                                                                  //
    }                                                                                                      //
    expiration = new Date(Date.now() + ops.expiration);                                                    // 3
    expiration = expiration.toISOString();                                                                 // 3
    key = ops.path + "/" + ops.file_name;                                                                  // 3
    policy = {                                                                                             // 3
      "expiration": expiration,                                                                            // 36
      "conditions": [                                                                                      // 36
        ["content-length-range", 0, ops.file_size], {                                                      //
          "key": key                                                                                       // 39
        }, {                                                                                               //
          "bucket": ops.bucket                                                                             // 40
        }, {                                                                                               //
          "Content-Type": ops.file_type                                                                    // 41
        }, {                                                                                               //
          "acl": ops.acl                                                                                   // 42
        }, {                                                                                               //
          "Content-Disposition": "inline; filename='" + ops.file_name + "'"                                // 43
        }                                                                                                  //
      ]                                                                                                    //
    };                                                                                                     //
    policy = Buffer(JSON.stringify(policy), "utf-8").toString("base64");                                   // 3
    signature = calculate_signature(policy);                                                               // 3
    if (ops.region === "us-east-1" || ops.region === "us-standard") {                                      // 53
      post_url = "https://s3.amazonaws.com/" + ops.bucket;                                                 // 54
    } else {                                                                                               //
      post_url = "https://s3-" + ops.region + ".amazonaws.com/" + ops.bucket;                              // 56
    }                                                                                                      //
    return {                                                                                               //
      policy: policy,                                                                                      // 59
      signature: signature,                                                                                // 59
      access_key: S3.config.key,                                                                           // 59
      post_url: post_url,                                                                                  // 59
      url: (post_url + "/" + key).replace("https://", "http://"),                                          // 59
      secure_url: post_url + "/" + key,                                                                    // 59
      relative_url: "/" + key,                                                                             // 59
      bucket: ops.bucket,                                                                                  // 59
      acl: ops.acl,                                                                                        // 59
      key: key,                                                                                            // 59
      file_type: ops.file_type,                                                                            // 59
      file_name: ops.file_name                                                                             // 59
    };                                                                                                     //
  }                                                                                                        //
});                                                                                                        //
                                                                                                           //
crypto = Npm.require("crypto");                                                                            // 1
                                                                                                           //
calculate_signature = function(policy) {                                                                   // 1
  return crypto.createHmac("sha1", S3.config.secret).update(new Buffer(policy, "utf-8")).digest("base64");
};                                                                                                         // 74
                                                                                                           //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/lepozepo_s3/server/delete_object.coffee.js                                                     //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Future;                                                                                                // 1
                                                                                                           //
Future = Npm.require('fibers/future');                                                                     // 1
                                                                                                           //
Meteor.methods({                                                                                           // 1
  _s3_delete: function(path) {                                                                             // 4
    var future;                                                                                            // 5
    this.unblock();                                                                                        // 5
    if (check) {                                                                                           // 6
      check(path, String);                                                                                 // 7
    }                                                                                                      //
    future = new Future();                                                                                 // 5
    S3.knox.deleteFile(path, function(e, r) {                                                              // 5
      if (e) {                                                                                             // 12
        console.log(e);                                                                                    // 13
        return future["return"](e);                                                                        //
      } else {                                                                                             //
        return future["return"](true);                                                                     //
      }                                                                                                    //
    });                                                                                                    //
    return future.wait();                                                                                  //
  }                                                                                                        //
});                                                                                                        //
                                                                                                           //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['lepozepo:s3'] = {
  Knox: Knox,
  AWS: AWS
};

})();

//# sourceMappingURL=lepozepo_s3.js.map
