(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:config'].orion;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

(function(){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/nicolaslopezj_orion-ga/packages/nicolaslopezj_orion-ga.js     //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
(function () {                                                            // 1
                                                                          // 2
///////////////////////////////////////////////////////////////////////   // 3
//                                                                   //   // 4
// packages/nicolaslopezj:orion-ga/config.js                         //   // 5
//                                                                   //   // 6
///////////////////////////////////////////////////////////////////////   // 7
                                                                     //   // 8
orion.config.add('GA_TRACKING_CODE', 'analytics', { public: true }); // 1
///////////////////////////////////////////////////////////////////////   // 10
                                                                          // 11
}).call(this);                                                            // 12
                                                                          // 13
////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nicolaslopezj:orion-ga'] = {};

})();

//# sourceMappingURL=nicolaslopezj_orion-ga.js.map
