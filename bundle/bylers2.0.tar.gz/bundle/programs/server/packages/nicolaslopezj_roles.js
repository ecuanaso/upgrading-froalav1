(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var objectHasKey, Roles;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/nicolaslopezj_roles/helpers.js                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
objectHasKey = function(object, key) {                                                                                // 1
  var dotNotation = {};                                                                                               // 2
                                                                                                                      // 3
  (function recurse(obj, current) {                                                                                   // 4
    for(var key in obj) {                                                                                             // 5
      var value = obj[key];                                                                                           // 6
      var newKey = (current ? current + "." + key : key);  // joined key with dot                                     // 7
      if(value && typeof value === "object") {                                                                        // 8
        recurse(value, newKey);  // it's a nested object, so do it again                                              // 9
      } else {                                                                                                        // 10
        dotNotation[newKey] = value;  // it's not an object, so set the property                                      // 11
      }                                                                                                               // 12
    }                                                                                                                 // 13
  })(object);                                                                                                         // 14
                                                                                                                      // 15
  var keys = _.keys(dotNotation);                                                                                     // 16
  var newKeys = [];                                                                                                   // 17
                                                                                                                      // 18
  _.each(keys, function(_key) {                                                                                       // 19
    var parts = _key.split('.');                                                                                      // 20
    var added = [];                                                                                                   // 21
    _.each(parts, function(part) {                                                                                    // 22
      if (!isNaN(part)) {                                                                                             // 23
        part = '$';                                                                                                   // 24
        added.push(part);                                                                                             // 25
      } else {                                                                                                        // 26
        added.push(part);                                                                                             // 27
        newKeys.push(added.join('.'));                                                                                // 28
      }                                                                                                               // 29
    });                                                                                                               // 30
  });                                                                                                                 // 31
                                                                                                                      // 32
  return _.contains(newKeys, key);                                                                                    // 33
};                                                                                                                    // 34
                                                                                                                      // 35
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/nicolaslopezj_roles/roles.js                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Init the variable                                                                                                  // 2
 */                                                                                                                   // 3
Roles = {};                                                                                                           // 4
                                                                                                                      // 5
/**                                                                                                                   // 6
 * Initialize variables                                                                                               // 7
 */                                                                                                                   // 8
Roles._roles = {};                                                                                                    // 9
Roles._actions = [];                                                                                                  // 10
Roles._helpers = [];                                                                                                  // 11
Roles._specialRoles = ['__loggedIn__', '__notAdmin__', '__notLoggedIn__', '__all__'];                                 // 12
                                                                                                                      // 13
/**                                                                                                                   // 14
 * To save the roles in the database                                                                                  // 15
 */                                                                                                                   // 16
Roles._collection = new Mongo.Collection('roles');                                                                    // 17
                                                                                                                      // 18
/**                                                                                                                   // 19
 * Get the list of roles                                                                                              // 20
 */                                                                                                                   // 21
Roles.availableRoles = function() {                                                                                   // 22
  return _.difference(_.keys(this._roles), this._specialRoles);                                                       // 23
};                                                                                                                    // 24
                                                                                                                      // 25
/**                                                                                                                   // 26
 * Check if a user has a role                                                                                         // 27
 */                                                                                                                   // 28
Roles.userHasRole = function(userId, role) {                                                                          // 29
  if (role == '__all__') return true;                                                                                 // 30
  if (role == '__notLoggedIn__' && !userId) return true;                                                              // 31
  if (role == '__default__' && userId) return true;                                                                   // 32
  if (role == '__notAdmin__' && this._collection.find({ userId: userId, roles: 'admin' }).count() === 0) return true;
  return this._collection.find({ userId: userId, roles: role }).count() > 0;                                          // 34
};                                                                                                                    // 35
                                                                                                                      // 36
/**                                                                                                                   // 37
 * Creates a new action                                                                                               // 38
 */                                                                                                                   // 39
Roles.registerAction = function(name, adminAllow, adminDeny) {                                                        // 40
  check(name, String);                                                                                                // 41
  check(adminAllow, Match.Optional(Match.Any));                                                                       // 42
  check(adminDeny, Match.Optional(Match.Any));                                                                        // 43
                                                                                                                      // 44
  this._actions.push(name);                                                                                           // 45
                                                                                                                      // 46
  if (adminAllow) {                                                                                                   // 47
    Roles.adminRole.allow(name, adminAllow);                                                                          // 48
  }                                                                                                                   // 49
  if (adminDeny) {                                                                                                    // 50
    Roles.adminRole.deny(name, adminDeny);                                                                            // 51
  }                                                                                                                   // 52
};                                                                                                                    // 53
                                                                                                                      // 54
/**                                                                                                                   // 55
 * Creates a new helper                                                                                               // 56
 */                                                                                                                   // 57
Roles.registerHelper = function(name, adminHelper) {                                                                  // 58
  check(name, String);                                                                                                // 59
  check(adminHelper, Match.Any);                                                                                      // 60
  this._helpers.push(name);                                                                                           // 61
                                                                                                                      // 62
  if (adminHelper) {                                                                                                  // 63
    Roles.adminRole.helper(name, adminHelper);                                                                        // 64
  }                                                                                                                   // 65
};                                                                                                                    // 66
                                                                                                                      // 67
/**                                                                                                                   // 68
 * Constructs a new role                                                                                              // 69
 */                                                                                                                   // 70
Roles.Role = function(name) {                                                                                         // 71
  check(name, String);                                                                                                // 72
                                                                                                                      // 73
  if (!(this instanceof Roles.Role))                                                                                  // 74
    throw new Error('use "new" to construct a role');                                                                 // 75
                                                                                                                      // 76
  if (_.has(Roles._roles, name))                                                                                      // 77
    throw new Error('"' + name + '" role is already defined');                                                        // 78
                                                                                                                      // 79
  this.name = name;                                                                                                   // 80
  this.allowRules = {};                                                                                               // 81
  this.denyRules = {};                                                                                                // 82
  this.helpers = {};                                                                                                  // 83
                                                                                                                      // 84
  Roles._roles[name] = this;                                                                                          // 85
};                                                                                                                    // 86
                                                                                                                      // 87
/**                                                                                                                   // 88
 * Adds allow properties to a role                                                                                    // 89
 */                                                                                                                   // 90
Roles.Role.prototype.allow = function(action, allow) {                                                                // 91
  check(action, String);                                                                                              // 92
  check(allow, Match.Any);                                                                                            // 93
  if (!_.contains(Roles._actions, action)) throw 'Action "' + action + '" is not defined';                            // 94
                                                                                                                      // 95
  if (!_.isFunction(allow)) {                                                                                         // 96
    var clone = _.clone(allow);                                                                                       // 97
    allow = function() {                                                                                              // 98
      return clone;                                                                                                   // 99
    };                                                                                                                // 100
  }                                                                                                                   // 101
                                                                                                                      // 102
  this.allowRules[action] = this.allowRules[action] || [];                                                            // 103
  this.allowRules[action].push(allow);                                                                                // 104
};                                                                                                                    // 105
                                                                                                                      // 106
/**                                                                                                                   // 107
 * Adds deny properties to a role                                                                                     // 108
 */                                                                                                                   // 109
Roles.Role.prototype.deny = function(action, deny) {                                                                  // 110
  check(action, String);                                                                                              // 111
  check(deny, Match.Any);                                                                                             // 112
  if (!_.contains(Roles._actions, action)) throw 'Action "' + action + '" is not defined';                            // 113
                                                                                                                      // 114
  if (!_.isFunction(deny)) {                                                                                          // 115
    var clone = _.clone(deny);                                                                                        // 116
    deny = function() {                                                                                               // 117
      return clone;                                                                                                   // 118
    };                                                                                                                // 119
  }                                                                                                                   // 120
                                                                                                                      // 121
  this.denyRules[action] = this.denyRules[action] || [];                                                              // 122
  this.denyRules[action].push(deny);                                                                                  // 123
};                                                                                                                    // 124
                                                                                                                      // 125
/**                                                                                                                   // 126
 * Adds a helper to a role                                                                                            // 127
 */                                                                                                                   // 128
Roles.Role.prototype.helper = function(helper, func) {                                                                // 129
  check(helper, String);                                                                                              // 130
  check(func, Match.Any);                                                                                             // 131
  if (!_.contains(Roles._helpers, helper)) throw 'Helper "' + helper + '" is not defined';                            // 132
                                                                                                                      // 133
  if (!_.isFunction(func)) {                                                                                          // 134
    var value = _.clone(func);                                                                                        // 135
    func = function() {                                                                                               // 136
      return value;                                                                                                   // 137
    };                                                                                                                // 138
  }                                                                                                                   // 139
                                                                                                                      // 140
  if (!this.helpers[helper]) {                                                                                        // 141
    this.helpers[helper] = [];                                                                                        // 142
  }                                                                                                                   // 143
                                                                                                                      // 144
  this.helpers[helper].push(func);                                                                                    // 145
};                                                                                                                    // 146
                                                                                                                      // 147
/**                                                                                                                   // 148
 * Get user roles                                                                                                     // 149
 */                                                                                                                   // 150
Roles.getUserRoles = function(userId, includeSpecial) {                                                               // 151
  check(userId, Match.OneOf(String, null, undefined));                                                                // 152
  check(includeSpecial, Match.Optional(Boolean));                                                                     // 153
  var object = Roles._collection.findOne({ userId: userId });                                                         // 154
  var roles = object ? object.roles : [];                                                                             // 155
  if (includeSpecial) {                                                                                               // 156
    roles.push('__all__');                                                                                            // 157
    if (!userId) {                                                                                                    // 158
      roles.push('__notLoggedIn__');                                                                                  // 159
    } else {                                                                                                          // 160
      roles.push('__loggedIn__');                                                                                     // 161
      if (!_.contains(roles, 'admin')) {                                                                              // 162
        roles.push('__notAdmin__');                                                                                   // 163
      }                                                                                                               // 164
    }                                                                                                                 // 165
  }                                                                                                                   // 166
  return roles;                                                                                                       // 167
};                                                                                                                    // 168
                                                                                                                      // 169
/**                                                                                                                   // 170
 * Calls a helper                                                                                                     // 171
 */                                                                                                                   // 172
Roles.helper = function(userId, helper) {                                                                             // 173
  check(userId, Match.OneOf(String, null, undefined));                                                                // 174
  check(helper, String);                                                                                              // 175
  if (!_.contains(this._helpers, helper)) throw 'Helper "' + helper + '" is not defined';                             // 176
                                                                                                                      // 177
  var args = _.toArray(arguments).slice(2);                                                                           // 178
  var self = this;                                                                                                    // 179
  var context = { userId: userId };                                                                                   // 180
  var responses = [];                                                                                                 // 181
  var roles = Roles.getUserRoles(userId, true);                                                                       // 182
                                                                                                                      // 183
  _.each(roles, function(role){                                                                                       // 184
    if (self._roles[role] && self._roles[role].helpers && self._roles[role].helpers[helper]) {                        // 185
      var helpers = self._roles[role].helpers[helper];                                                                // 186
      _.each(helpers, function(helper) {                                                                              // 187
        responses.push(helper.apply(context, args));                                                                  // 188
      });                                                                                                             // 189
    }                                                                                                                 // 190
  });                                                                                                                 // 191
                                                                                                                      // 192
  return responses;                                                                                                   // 193
};                                                                                                                    // 194
                                                                                                                      // 195
/**                                                                                                                   // 196
 * Returns if the user passes the allow check                                                                         // 197
 */                                                                                                                   // 198
Roles.allow = function(userId, action) {                                                                              // 199
  check(userId, Match.OneOf(String, null, undefined));                                                                // 200
  check(action, String);                                                                                              // 201
                                                                                                                      // 202
  var args = _.toArray(arguments).slice(2);                                                                           // 203
  var self = this;                                                                                                    // 204
  var context = { userId: userId };                                                                                   // 205
  var allowed = false;                                                                                                // 206
  var roles = Roles.getUserRoles(userId, true);                                                                       // 207
                                                                                                                      // 208
  _.each(roles, function(role){                                                                                       // 209
    if (!allowed && self._roles[role] && self._roles[role].allowRules && self._roles[role].allowRules[action]) {      // 210
      _.each(self._roles[role].allowRules[action], function(func){                                                    // 211
        var allow = func.apply(context, args);                                                                        // 212
        if (allow === true) {                                                                                         // 213
          allowed = true;                                                                                             // 214
        }                                                                                                             // 215
      });                                                                                                             // 216
    }                                                                                                                 // 217
  });                                                                                                                 // 218
                                                                                                                      // 219
  return allowed;                                                                                                     // 220
};                                                                                                                    // 221
                                                                                                                      // 222
/**                                                                                                                   // 223
 * Returns if the user has permission using deny and deny                                                             // 224
 */                                                                                                                   // 225
Roles.deny = function(userId, action) {                                                                               // 226
  check(userId, Match.OneOf(String, null, undefined));                                                                // 227
  check(action, String);                                                                                              // 228
                                                                                                                      // 229
  var args = _.toArray(arguments).slice(2);                                                                           // 230
  var self = this;                                                                                                    // 231
  var context = { userId: userId };                                                                                   // 232
  var denied = false;                                                                                                 // 233
  var roles = Roles.getUserRoles(userId, true);                                                                       // 234
                                                                                                                      // 235
  _.each(roles, function(role){                                                                                       // 236
    if (!denied && self._roles[role] && self._roles[role].denyRules && self._roles[role].denyRules[action]) {         // 237
      _.each(self._roles[role].denyRules[action], function(func){                                                     // 238
        var denies = func.apply(context, args);                                                                       // 239
        if (denies === true) {                                                                                        // 240
          denied = true;                                                                                              // 241
        }                                                                                                             // 242
      });                                                                                                             // 243
    }                                                                                                                 // 244
  });                                                                                                                 // 245
                                                                                                                      // 246
  return denied;                                                                                                      // 247
};                                                                                                                    // 248
                                                                                                                      // 249
/**                                                                                                                   // 250
 * To check if a user has permisisons to execute an action                                                            // 251
 */                                                                                                                   // 252
Roles.userHasPermission = function() {                                                                                // 253
  var allows = this.allow.apply(this, arguments);                                                                     // 254
  var denies = this.deny.apply(this, arguments);                                                                      // 255
  return allows === true && denies === false;                                                                         // 256
};                                                                                                                    // 257
                                                                                                                      // 258
/**                                                                                                                   // 259
 * If the user doesn't has permission it will throw a error                                                           // 260
 */                                                                                                                   // 261
Roles.checkPermission = function() {                                                                                  // 262
  if (!this.userHasPermission.apply(this, arguments)) {                                                               // 263
    throw new Meteor.Error('unauthorized', 'The user has no permission to perform this action');                      // 264
  }                                                                                                                   // 265
};                                                                                                                    // 266
                                                                                                                      // 267
/**                                                                                                                   // 268
 * Adds helpers to users                                                                                              // 269
 */                                                                                                                   // 270
Meteor.users.helpers({                                                                                                // 271
  /**                                                                                                                 // 272
   * Returns the user roles                                                                                           // 273
   */                                                                                                                 // 274
  roles: function (includeSpecial) {                                                                                  // 275
    return Roles.getUserRoles(this._id, includeSpecial);                                                              // 276
  },                                                                                                                  // 277
  /**                                                                                                                 // 278
   * To check if the user has a role                                                                                  // 279
   */                                                                                                                 // 280
  hasRole: function(role) {                                                                                           // 281
    return Roles.userHasRole(this._id, role);                                                                         // 282
  }                                                                                                                   // 283
});                                                                                                                   // 284
                                                                                                                      // 285
/**                                                                                                                   // 286
 * The admin role, who recives the default actions.                                                                   // 287
 */                                                                                                                   // 288
Roles.adminRole = new Roles.Role('admin'); Roles._adminRole = Roles.adminRole; // Backwards compatibility             // 289
/**                                                                                                                   // 290
 * All the logged in users users                                                                                      // 291
 */                                                                                                                   // 292
Roles.loggedInRole = new Roles.Role('__loggedIn__'); Roles.defaultRole = Roles.loggedInRole; // Backwards compatibility
/**                                                                                                                   // 294
 * The users that are not admins                                                                                      // 295
 */                                                                                                                   // 296
Roles.notAdminRole = new Roles.Role('__notAdmin__');                                                                  // 297
/**                                                                                                                   // 298
 * The users that are not logged in                                                                                   // 299
 */                                                                                                                   // 300
Roles.notLoggedInRole = new Roles.Role('__notLoggedIn__');                                                            // 301
/**                                                                                                                   // 302
 * Always, no exception                                                                                               // 303
 */                                                                                                                   // 304
Roles.allRole = new Roles.Role('__all__');                                                                            // 305
                                                                                                                      // 306
                                                                                                                      // 307
/**                                                                                                                   // 308
 * A Helper to attach actions to collections easily                                                                   // 309
 */                                                                                                                   // 310
Mongo.Collection.prototype.attachRoles = function(name, dontAllow) {                                                  // 311
  Roles.registerAction(name + '.insert', !dontAllow);                                                                 // 312
  Roles.registerAction(name + '.update', !dontAllow);                                                                 // 313
  Roles.registerAction(name + '.remove', !dontAllow);                                                                 // 314
  Roles.registerHelper(name + '.forbiddenFields', []);                                                                // 315
                                                                                                                      // 316
  this.allow({                                                                                                        // 317
    insert: function(userId, doc) {                                                                                   // 318
      return Roles.allow(userId, name + '.insert', userId, doc);                                                      // 319
    },                                                                                                                // 320
    update: function(userId, doc, fields, modifier) {                                                                 // 321
      return Roles.allow(userId, name + '.update', userId, doc, fields, modifier);                                    // 322
    },                                                                                                                // 323
    remove: function(userId, doc) {                                                                                   // 324
      return Roles.allow(userId, name + '.remove', userId, doc);                                                      // 325
    }                                                                                                                 // 326
  });                                                                                                                 // 327
                                                                                                                      // 328
  this.deny({                                                                                                         // 329
    insert: function(userId, doc) {                                                                                   // 330
      return Roles.deny(userId, name + '.insert', userId, doc);                                                       // 331
    },                                                                                                                // 332
    update: function(userId, doc, fields, modifier) {                                                                 // 333
      return Roles.deny(userId, name + '.update', userId, doc, fields, modifier);                                     // 334
    },                                                                                                                // 335
    remove: function(userId, doc) {                                                                                   // 336
      return Roles.deny(userId, name + '.remove', userId, doc);                                                       // 337
    }                                                                                                                 // 338
  });                                                                                                                 // 339
                                                                                                                      // 340
  this.deny({                                                                                                         // 341
    insert: function(userId, doc) {                                                                                   // 342
      var forbiddenFields = _.union.apply(this, Roles.helper(userId, name + '.forbiddenFields'));                     // 343
                                                                                                                      // 344
      for (var i in forbiddenFields) {                                                                                // 345
        var field = forbiddenFields[i];                                                                               // 346
        if (objectHasKey(doc, field)) {                                                                               // 347
          return true;                                                                                                // 348
        }                                                                                                             // 349
      }                                                                                                               // 350
    },                                                                                                                // 351
    update: function(userId, doc, fields, modifier) {                                                                 // 352
      var forbiddenFields = _.union.apply(this, Roles.helper(userId, name + '.forbiddenFields', doc._id));            // 353
      var types = ['$inc', '$mul', '$rename', '$setOnInsert', '$set', '$unset', '$min', '$max', '$currentDate'];      // 354
                                                                                                                      // 355
      for (var i in forbiddenFields) {                                                                                // 356
        var field = forbiddenFields[i];                                                                               // 357
        for (var j in types) {                                                                                        // 358
          var type = types[j];                                                                                        // 359
          if (objectHasKey(modifier, type + '.' + field)) {                                                           // 360
            return true;                                                                                              // 361
          }                                                                                                           // 362
        }                                                                                                             // 363
      }                                                                                                               // 364
    }                                                                                                                 // 365
  });                                                                                                                 // 366
};                                                                                                                    // 367
                                                                                                                      // 368
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/nicolaslopezj_roles/keys.js                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Roles.keys = {};                                                                                                      // 1
                                                                                                                      // 2
/**                                                                                                                   // 3
 * Initialize the collection                                                                                          // 4
 */                                                                                                                   // 5
Roles.keys.collection = new Meteor.Collection('nicolaslopezj_roles_keys');                                            // 6
                                                                                                                      // 7
/**                                                                                                                   // 8
 * Set the permissions                                                                                                // 9
 * Users can request keys just for them                                                                               // 10
 */                                                                                                                   // 11
Roles.keys.collection.allow({                                                                                         // 12
  insert: function(userId, doc) {                                                                                     // 13
    return userId === doc.userId;                                                                                     // 14
  },                                                                                                                  // 15
  remove: function(userId, doc) {                                                                                     // 16
    return userId === doc.userId;                                                                                     // 17
  }                                                                                                                   // 18
})                                                                                                                    // 19
                                                                                                                      // 20
/**                                                                                                                   // 21
 * Requests a new key                                                                                                 // 22
 * @param  {String} userId Id of the userId                                                                           // 23
 * @return {String}        Id of the key                                                                              // 24
 */                                                                                                                   // 25
Roles.keys.request = function(userId) {                                                                               // 26
  return this.collection.insert({                                                                                     // 27
    userId: userId,                                                                                                   // 28
    createdAt: new Date()                                                                                             // 29
  });                                                                                                                 // 30
};                                                                                                                    // 31
                                                                                                                      // 32
/**                                                                                                                   // 33
 * Returns the userId of the specified key and deletes the key from the database                                      // 34
 * @param  {String}  key                                                                                              // 35
 * @param  {Boolean} dontDelete True to leave the key in the database                                                 // 36
 * @return {String}             Id of the user                                                                        // 37
 */                                                                                                                   // 38
Roles.keys.getUserId = function(key, dontDelete) {                                                                    // 39
  check(key, String);                                                                                                 // 40
  check(dontDelete, Match.Optional(Boolean));                                                                         // 41
                                                                                                                      // 42
  var doc = this.collection.findOne({ _id: key });                                                                    // 43
                                                                                                                      // 44
  if (!dontDelete) {                                                                                                  // 45
    this.collection.remove({ _id: key });                                                                             // 46
  }                                                                                                                   // 47
                                                                                                                      // 48
  return doc && doc.userId;                                                                                           // 49
}                                                                                                                     // 50
                                                                                                                      // 51
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/nicolaslopezj_roles/roles_server.js                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/**                                                                                                                   // 1
 * Ensure mongo index                                                                                                 // 2
 */                                                                                                                   // 3
Roles._collection._ensureIndex('userId', { unique: true });                                                           // 4
                                                                                                                      // 5
/**                                                                                                                   // 6
 * Publish user roles                                                                                                 // 7
 */                                                                                                                   // 8
Meteor.publish('nicolaslopezj_roles', function () {                                                                   // 9
  return Roles._collection.find({ userId: this.userId });                                                             // 10
})                                                                                                                    // 11
                                                                                                                      // 12
                                                                                                                      // 13
/**                                                                                                                   // 14
 * Adds roles to a user                                                                                               // 15
 */                                                                                                                   // 16
Roles.addUserToRoles = function(userId, roles) {                                                                      // 17
  check(userId, String);                                                                                              // 18
  check(roles, Match.OneOf(String, Array));                                                                           // 19
  if (!_.isArray(roles)) {                                                                                            // 20
    roles = [roles];                                                                                                  // 21
  }                                                                                                                   // 22
  return Roles._collection.upsert({ userId: userId }, { $addToSet: { roles: { $each: roles } } });                    // 23
}                                                                                                                     // 24
                                                                                                                      // 25
/**                                                                                                                   // 26
 * Set user roles                                                                                                     // 27
 */                                                                                                                   // 28
Roles.setUserRoles = function(userId, roles) {                                                                        // 29
  check(userId, String);                                                                                              // 30
  check(roles, Match.OneOf(String, Array));                                                                           // 31
  if (!_.isArray(roles)) {                                                                                            // 32
    roles = [roles];                                                                                                  // 33
  }                                                                                                                   // 34
  return Roles._collection.upsert({ userId: userId }, { $set: { roles: roles } });                                    // 35
}                                                                                                                     // 36
                                                                                                                      // 37
/**                                                                                                                   // 38
 * Removes roles from a user                                                                                          // 39
 */                                                                                                                   // 40
Roles.removeUserFromRoles = function(userId, roles) {                                                                 // 41
  check(userId, String);                                                                                              // 42
  check(roles, Match.OneOf(String, Array));                                                                           // 43
  if (!_.isArray(roles)) {                                                                                            // 44
    roles = [roles];                                                                                                  // 45
  }                                                                                                                   // 46
  return Roles._collection.update({ userId: userId }, { $pullAll: { roles: roles } });                                // 47
}                                                                                                                     // 48
                                                                                                                      // 49
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nicolaslopezj:roles'] = {
  Roles: Roles,
  objectHasKey: objectHasKey
};

})();

//# sourceMappingURL=nicolaslopezj_roles.js.map
