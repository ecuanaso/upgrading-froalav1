(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/sjors_meteor-masonry/packages/sjors_meteor-masonry.js    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['sjors:meteor-masonry'] = {};

})();

//# sourceMappingURL=sjors_meteor-masonry.js.map
