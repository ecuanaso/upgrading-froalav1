(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var UrlUtils;

(function(){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/peerlibrary_url-utils/packages/peerlibrary_url-utils.js       //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
(function () {                                                            // 1
                                                                          // 2
///////////////////////////////////////////////////////////////////////   // 3
//                                                                   //   // 4
// packages/peerlibrary:url-utils/server.js                          //   // 5
//                                                                   //   // 6
///////////////////////////////////////////////////////////////////////   // 7
                                                                     //   // 8
UrlUtils = Npm.require('node-url-utils');                            // 1
                                                                     // 2
///////////////////////////////////////////////////////////////////////   // 11
                                                                          // 12
}).call(this);                                                            // 13
                                                                          // 14
////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['peerlibrary:url-utils'] = {
  UrlUtils: UrlUtils
};

})();

//# sourceMappingURL=peerlibrary_url-utils.js.map
