(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;

/* Package-scope variables */
var reCAPTCHA;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/ayue_recaptcha/packages/ayue_recaptcha.js                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
(function () {                                                                                                       // 1
                                                                                                                     // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////    // 3
//                                                                                                             //    // 4
// packages/ayue:recaptcha/server/server.js                                                                    //    // 5
//                                                                                                             //    // 6
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////    // 7
                                                                                                               //    // 8
reCAPTCHA = {                                                                                                  // 1  // 9
    settings: {},                                                                                              // 2  // 10
    config: function(settings) {                                                                               // 3  // 11
        return _.extend(this.settings, settings);                                                              // 4  // 12
    },                                                                                                         // 5  // 13
    verifyCaptcha: function(recaptchaResponse, clientIP) {                                                     // 6  // 14
        var captcha_data = {                                                                                   // 7  // 15
            secret: this.settings.privatekey, // for prod: process.env.RECAPTCHA_PRIVATE_KEY,                  // 8  // 16
            remoteip: clientIP,                                                                                // 9  // 17
            response: recaptchaResponse                                                                        // 10
        };                                                                                                     // 11
                                                                                                               // 12
        var serialized_captcha_data =                                                                          // 13
            'secret=' + captcha_data.secret +                                                                  // 14
            '&remoteip=' + captcha_data.remoteip +                                                             // 15
            '&response=' + captcha_data.response;                                                              // 16
        var captchaVerificationResult = null;                                                                  // 17
        var success, parts; // used to process response string                                                 // 18
                                                                                                               // 19
        try {                                                                                                  // 20
            captchaVerificationResult = HTTP.call("POST", "https://www.google.com/recaptcha/api/siteverify", { // 21
                content: serialized_captcha_data.toString('utf8'),                                             // 22
                headers: {                                                                                     // 23
                    'Content-Type': 'application/x-www-form-urlencoded',                                       // 24
                    'Content-Length': serialized_captcha_data.length                                           // 25
                }                                                                                              // 26
            });                                                                                                // 27
        } catch (e) {                                                                                          // 28
            console.log(e);                                                                                    // 29
            return {                                                                                           // 30
                'success': false,                                                                              // 31
                'error': 'Service Not Available'                                                               // 32
            };                                                                                                 // 33
        }                                                                                                      // 34
                                                                                                               // 35
        parts = captchaVerificationResult.content.split('\n');                                                 // 36
        success = parts[1];                                                                                    // 37
                                                                                                               // 38
        if (success.indexOf('true') < 0) {                                                                     // 39
            return {                                                                                           // 40
                'success': false,                                                                              // 41
                'error': 'reCAPTCHA verification failed'                                                       // 42
            };                                                                                                 // 43
        }                                                                                                      // 44
                                                                                                               // 45
        return {                                                                                               // 46
            'success': true                                                                                    // 47
        };                                                                                                     // 48
    }                                                                                                          // 49
}                                                                                                              // 50
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////    // 59
                                                                                                                     // 60
}).call(this);                                                                                                       // 61
                                                                                                                     // 62
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ayue:recaptcha'] = {
  reCAPTCHA: reCAPTCHA
};

})();

//# sourceMappingURL=ayue_recaptcha.js.map
