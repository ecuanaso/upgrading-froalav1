(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var RouterLayer;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nicolaslopezj_router-layer/packages/nicolaslopezj_router-layer.js                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
(function () {                                                                                                       // 1
                                                                                                                     // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 3
//                                                                                                            //     // 4
// packages/nicolaslopezj:router-layer/layer.js                                                               //     // 5
//                                                                                                            //     // 6
////////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 7
                                                                                                              //     // 8
/**                                                                                                           // 1   // 9
 * Namespace for Router Layer                                                                                 // 2   // 10
 */                                                                                                           // 3   // 11
RouterLayer = {};                                                                                             // 4   // 12
                                                                                                              // 5   // 13
/**                                                                                                           // 6   // 14
 * The router package name                                                                                    // 7   // 15
 * @type {String}                                                                                             // 8   // 16
 */                                                                                                           // 9   // 17
RouterLayer.router = null;                                                                                    // 10  // 18
                                                                                                              // 11  // 19
/**                                                                                                           // 12  // 20
 * Check if uses iron router                                                                                  // 13  // 21
 */                                                                                                           // 14  // 22
if (_.has(Package, 'iron:router')) {                                                                          // 15  // 23
  RouterLayer.router = 'iron-router';                                                                         // 16  // 24
  RouterLayer.ironRouter = Package['iron:router'].Router;                                                     // 17  // 25
}                                                                                                             // 18  // 26
                                                                                                              // 19  // 27
/**                                                                                                           // 20  // 28
 * Check if uses flow router                                                                                  // 21  // 29
 */                                                                                                           // 22  // 30
if (_.has(Package, 'kadira:flow-router')) {                                                                   // 23  // 31
  RouterLayer.router = 'flow-router';                                                                         // 24  // 32
  if (!_.has(Package, 'kadira:blaze-layout')) {                                                               // 25  // 33
    throw new Meteor.Error('router-layer', 'If you use kadira:flow-router you must add kadira:blaze-layout'); // 26  // 34
  }                                                                                                           // 27  // 35
  RouterLayer.flowRouter = Package['kadira:flow-router'].FlowRouter;                                          // 28  // 36
  RouterLayer.blazeLayout = Package['kadira:blaze-layout'].BlazeLayout;                                       // 29  // 37
}                                                                                                             // 30  // 38
                                                                                                              // 31  // 39
/*                                                                                                            // 32  // 40
 * Throw a error if there is no route package                                                                 // 33  // 41
 */                                                                                                           // 34  // 42
if (!RouterLayer.router) {                                                                                    // 35  // 43
  throw new Meteor.Error('router-layer', 'You must add iron:router or kadira:flow-router');                   // 36  // 44
}                                                                                                             // 37  // 45
                                                                                                              // 38  // 46
/**                                                                                                           // 39  // 47
 * Creates a new route                                                                                        // 40  // 48
 * @param {String} url                        The path of the route                                           // 41  // 49
 * @param {Object} [options]                                                                                  // 42  // 50
 * @param {String} options.template           The template for this route                                     // 43  // 51
 * @param {String} options.name               The name of the route                                           // 44  // 52
 * @param {String} options.layout             Optional. The layout for this route                             // 45  // 53
 * @param {Boolean} options.reactiveTemplates Optional. Templates are reactive templates                      // 46  // 54
 */                                                                                                           // 47  // 55
RouterLayer.route = function(url, options) {                                                                  // 48  // 56
  check(url, String);                                                                                         // 49  // 57
  check(options, {                                                                                            // 50  // 58
    template: String,                                                                                         // 51  // 59
    name: Match.Optional(String),                                                                             // 52  // 60
    layout: Match.Optional(String),                                                                           // 53  // 61
    reactiveTemplates: Match.Optional(Boolean)                                                                // 54  // 62
  });                                                                                                         // 55  // 63
                                                                                                              // 56  // 64
  this._route(url, options);                                                                                  // 57  // 65
};                                                                                                            // 58  // 66
                                                                                                              // 59  // 67
/**                                                                                                           // 60  // 68
 * Returns the path for a route                                                                               // 61  // 69
 * @param  {String} routeName The name of the route                                                           // 62  // 70
 * @param  {Object} params    Parameters for the route                                                        // 63  // 71
 * @return {String}           The requested url                                                               // 64  // 72
 */                                                                                                           // 65  // 73
RouterLayer.pathFor = function(routeName, params) {                                                           // 66  // 74
  check(routeName, String);                                                                                   // 67  // 75
  // check(params, Match.Optional(Object)); Gives error when passing collection documents                     // 68  // 76
                                                                                                              // 69  // 77
  return this._pathFor(routeName, params);                                                                    // 70  // 78
}                                                                                                             // 71  // 79
                                                                                                              // 72  // 80
/**                                                                                                           // 73  // 81
 * Check if the current route has the specified name and params (if set)                                      // 74  // 82
 * @param  {String} routeName The name of the route                                                           // 75  // 83
 * @param  {Object} params    Optional. The parameters of the route                                           // 76  // 84
 * @return {Boolean}          True if the route is active                                                     // 77  // 85
 */                                                                                                           // 78  // 86
RouterLayer.isActiveRoute = function(routeName, params) {                                                     // 79  // 87
  check(routeName, String);                                                                                   // 80  // 88
  check(params, Match.Optional(Object));                                                                      // 81  // 89
                                                                                                              // 82  // 90
  return this._isActiveRoute(routeName, params);                                                              // 83  // 91
}                                                                                                             // 84  // 92
                                                                                                              // 85  // 93
/**                                                                                                           // 86  // 94
 * Check if the current route name, divided by dots, starts with the specified name                           // 87  // 95
 * @param  {String} routeName The name of the route                                                           // 88  // 96
 * @return {Boolean}          True if the route is active                                                     // 89  // 97
 */                                                                                                           // 90  // 98
RouterLayer.isActiveRoutePartial = function(routeName) {                                                      // 91  // 99
  check(routeName, String);                                                                                   // 92  // 100
                                                                                                              // 93  // 101
  return this._isActiveRoutePartial(routeName);                                                               // 94  // 102
}                                                                                                             // 95  // 103
                                                                                                              // 96  // 104
/**                                                                                                           // 97  // 105
 * Redirects the user to the specified route                                                                  // 98  // 106
 * @param  {String} routeName The name of the route                                                           // 99  // 107
 * @param  {Object} params    Optional. The parameters of the route                                           // 100
 */                                                                                                           // 101
RouterLayer.go = function(routeName, params) {                                                                // 102
  check(routeName, String);                                                                                   // 103
  // check(params, Match.Optional(Object)); Gives error when passing collection documents                     // 104
                                                                                                              // 105
  this._go(routeName, params);                                                                                // 106
}                                                                                                             // 107
                                                                                                              // 108
/**                                                                                                           // 109
 * Returns a parameter of the url                                                                             // 110
 * @param  {String} paramName The name of the parameter                                                       // 111
 */                                                                                                           // 112
RouterLayer.getParam = function(paramName) {                                                                  // 113
  check(paramName, String);                                                                                   // 114
                                                                                                              // 115
  return this._getParam(paramName);                                                                           // 116
}                                                                                                             // 117
                                                                                                              // 118
/**                                                                                                           // 119
 * Returns a parameter of the url query                                                                       // 120
 * @param  {String} queryStringKey The name of the parameter                                                  // 121
 */                                                                                                           // 122
RouterLayer.getQueryParam = function(queryStringKey) {                                                        // 123
  check(queryStringKey, String);                                                                              // 124
                                                                                                              // 125
  return this._getQueryParam(queryStringKey);                                                                 // 126
}                                                                                                             // 127
                                                                                                              // 128
/**                                                                                                           // 129
 * Returns the path of the current route                                                                      // 130
 * @return {String} The path of the current route                                                             // 131
 */                                                                                                           // 132
RouterLayer.getPath = function() {                                                                            // 133
  return this._getPath();                                                                                     // 134
}                                                                                                             // 135
                                                                                                              // 136
////////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 145
                                                                                                                     // 146
}).call(this);                                                                                                       // 147
                                                                                                                     // 148
                                                                                                                     // 149
                                                                                                                     // 150
                                                                                                                     // 151
                                                                                                                     // 152
                                                                                                                     // 153
(function () {                                                                                                       // 154
                                                                                                                     // 155
////////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 156
//                                                                                                            //     // 157
// packages/nicolaslopezj:router-layer/iron-router.js                                                         //     // 158
//                                                                                                            //     // 159
////////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 160
                                                                                                              //     // 161
if (RouterLayer.router == 'iron-router') {                                                                    // 1   // 162
  RouterLayer._route = function(url, options) {                                                               // 2   // 163
    this.ironRouter.route(url, function() {                                                                   // 3   // 164
      if (options.reactiveTemplates) {                                                                        // 4   // 165
        options.layout && this.layout(ReactiveTemplates.get(options.layout));                                 // 5   // 166
        this.render(ReactiveTemplates.get(options.template));                                                 // 6   // 167
      } else {                                                                                                // 7   // 168
        options.layout && this.layout(options.layout);                                                        // 8   // 169
        this.render(options.template);                                                                        // 9   // 170
      }                                                                                                       // 10  // 171
    }, { name: options.name });                                                                               // 11  // 172
  };                                                                                                          // 12  // 173
                                                                                                              // 13  // 174
  RouterLayer._pathFor = function(routeName, params) {                                                        // 14  // 175
    return this.ironRouter.path(routeName, params);                                                           // 15  // 176
  }                                                                                                           // 16  // 177
                                                                                                              // 17  // 178
  RouterLayer._isActiveRoute = function(routeName, params) {                                                  // 18  // 179
    var currentRoute = this.ironRouter.current();                                                             // 19  // 180
    var isActive = true;                                                                                      // 20  // 181
                                                                                                              // 21  // 182
    if (currentRoute.route.getName() !== routeName) {                                                         // 22  // 183
      isActive = false;                                                                                       // 23  // 184
    }                                                                                                         // 24  // 185
                                                                                                              // 25  // 186
    if (!params) {                                                                                            // 26  // 187
      return isActive;                                                                                        // 27  // 188
    }                                                                                                         // 28  // 189
                                                                                                              // 29  // 190
    _.each(_.keys(params), function(key) {                                                                    // 30  // 191
      if (params[key] !== currentRoute.params[key]) {                                                         // 31  // 192
        isActive = false;                                                                                     // 32  // 193
      }                                                                                                       // 33  // 194
    });                                                                                                       // 34  // 195
                                                                                                              // 35  // 196
    return isActive;                                                                                          // 36  // 197
  }                                                                                                           // 37  // 198
                                                                                                              // 38  // 199
  RouterLayer._isActiveRoutePartial = function(routeName) {                                                   // 39  // 200
    var currentRouteName = this.ironRouter.current().route.getName().split('.');                              // 40  // 201
    var parts = routeName.split('.');                                                                         // 41  // 202
                                                                                                              // 42  // 203
    for(var i = 0; i < parts.length; i++) {                                                                   // 43  // 204
      if (currentRouteName[i] !== parts[i]) {                                                                 // 44  // 205
        return false;                                                                                         // 45  // 206
      }                                                                                                       // 46  // 207
    }                                                                                                         // 47  // 208
                                                                                                              // 48  // 209
    return true;                                                                                              // 49  // 210
  }                                                                                                           // 50  // 211
                                                                                                              // 51  // 212
  RouterLayer._go = function(routeName, params) {                                                             // 52  // 213
    this.ironRouter.go(routeName, params);                                                                    // 53  // 214
  }                                                                                                           // 54  // 215
                                                                                                              // 55  // 216
  RouterLayer._getParam = function(paramName) {                                                               // 56  // 217
    return this.ironRouter.current().params[paramName];                                                       // 57  // 218
  }                                                                                                           // 58  // 219
                                                                                                              // 59  // 220
  RouterLayer._getQueryParam = function(queryStringKey) {                                                     // 60  // 221
    return this.ironRouter.current().params.query[queryStringKey];                                            // 61  // 222
  }                                                                                                           // 62  // 223
                                                                                                              // 63  // 224
  RouterLayer._getPath = function() {                                                                         // 64  // 225
    return this.ironRouter.current().location.get().path                                                      // 65  // 226
  }                                                                                                           // 66  // 227
}                                                                                                             // 67  // 228
                                                                                                              // 68  // 229
////////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 230
                                                                                                                     // 231
}).call(this);                                                                                                       // 232
                                                                                                                     // 233
                                                                                                                     // 234
                                                                                                                     // 235
                                                                                                                     // 236
                                                                                                                     // 237
                                                                                                                     // 238
(function () {                                                                                                       // 239
                                                                                                                     // 240
////////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 241
//                                                                                                            //     // 242
// packages/nicolaslopezj:router-layer/flow-router.js                                                         //     // 243
//                                                                                                            //     // 244
////////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 245
                                                                                                              //     // 246
if (RouterLayer.router == 'flow-router') {                                                                    // 1   // 247
  RouterLayer._route = function(url, options) {                                                               // 2   // 248
    var self = this;                                                                                          // 3   // 249
                                                                                                              // 4   // 250
    self.flowRouter.route(url, {                                                                              // 5   // 251
      name: options.name,                                                                                     // 6   // 252
      action: function(params) {                                                                              // 7   // 253
        if (options.reactiveTemplates) {                                                                      // 8   // 254
          Tracker.autorun(function() {                                                                        // 9   // 255
            if (options.layout) {                                                                             // 10  // 256
              self.blazeLayout.render(ReactiveTemplates.get(options.layout), { content: ReactiveTemplates.get(options.template) });
            } else {                                                                                          // 12  // 258
              self.blazeLayout.render(ReactiveTemplates.get(options.template));                               // 13  // 259
            }                                                                                                 // 14  // 260
          });                                                                                                 // 15  // 261
        } else {                                                                                              // 16  // 262
          if (options.layout) {                                                                               // 17  // 263
            self.blazeLayout.render(options.layout, { content: options.template });                           // 18  // 264
          } else {                                                                                            // 19  // 265
            self.blazeLayout.render(options.template);                                                        // 20  // 266
          }                                                                                                   // 21  // 267
        }                                                                                                     // 22  // 268
      }                                                                                                       // 23  // 269
    });                                                                                                       // 24  // 270
  };                                                                                                          // 25  // 271
                                                                                                              // 26  // 272
  RouterLayer._pathFor = function(routeName, params) {                                                        // 27  // 273
    return this.flowRouter.path(routeName, params);                                                           // 28  // 274
  }                                                                                                           // 29  // 275
                                                                                                              // 30  // 276
  RouterLayer._isActiveRoute = function(routeName, params) {                                                  // 31  // 277
    var isActive = true;                                                                                      // 32  // 278
                                                                                                              // 33  // 279
    if (this.flowRouter.getRouteName() !== routeName) {                                                       // 34  // 280
      isActive = false;                                                                                       // 35  // 281
    }                                                                                                         // 36  // 282
                                                                                                              // 37  // 283
    if (!params) {                                                                                            // 38  // 284
      return isActive;                                                                                        // 39  // 285
    }                                                                                                         // 40  // 286
                                                                                                              // 41  // 287
    var self = this;                                                                                          // 42  // 288
    _.each(_.keys(params), function(key) {                                                                    // 43  // 289
      if (params[key] !== self.flowRouter.getParam(key)) {                                                    // 44  // 290
        isActive = false;                                                                                     // 45  // 291
      }                                                                                                       // 46  // 292
    });                                                                                                       // 47  // 293
                                                                                                              // 48  // 294
    return isActive;                                                                                          // 49  // 295
  }                                                                                                           // 50  // 296
                                                                                                              // 51  // 297
  RouterLayer._isActiveRoutePartial = function(routeName) {                                                   // 52  // 298
    var currentRouteName = this.flowRouter.getRouteName().split('.');                                         // 53  // 299
    var parts = routeName.split('.');                                                                         // 54  // 300
                                                                                                              // 55  // 301
    for(var i = 0; i < parts.length; i++) {                                                                   // 56  // 302
      if (currentRouteName[i] !== parts[i]) {                                                                 // 57  // 303
        return false;                                                                                         // 58  // 304
      }                                                                                                       // 59  // 305
    }                                                                                                         // 60  // 306
                                                                                                              // 61  // 307
    return true;                                                                                              // 62  // 308
  }                                                                                                           // 63  // 309
                                                                                                              // 64  // 310
  RouterLayer._go = function(routeName, params) {                                                             // 65  // 311
    this.flowRouter.go(routeName, params);                                                                    // 66  // 312
  }                                                                                                           // 67  // 313
                                                                                                              // 68  // 314
  RouterLayer._getParam = function(paramName) {                                                               // 69  // 315
    return this.flowRouter.getParam(paramName);                                                               // 70  // 316
  }                                                                                                           // 71  // 317
                                                                                                              // 72  // 318
  RouterLayer._getQueryParam = function(queryStringKey) {                                                     // 73  // 319
    return this.flowRouter.getQueryParam(queryStringKey);                                                     // 74  // 320
  }                                                                                                           // 75  // 321
                                                                                                              // 76  // 322
  RouterLayer._getPath = function() {                                                                         // 77  // 323
    this.flowRouter.watchPathChange();                                                                        // 78  // 324
    return this.flowRouter.current().path;                                                                    // 79  // 325
  }                                                                                                           // 80  // 326
}                                                                                                             // 81  // 327
                                                                                                              // 82  // 328
////////////////////////////////////////////////////////////////////////////////////////////////////////////////     // 329
                                                                                                                     // 330
}).call(this);                                                                                                       // 331
                                                                                                                     // 332
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nicolaslopezj:router-layer'] = {
  RouterLayer: RouterLayer
};

})();

//# sourceMappingURL=nicolaslopezj_router-layer.js.map
