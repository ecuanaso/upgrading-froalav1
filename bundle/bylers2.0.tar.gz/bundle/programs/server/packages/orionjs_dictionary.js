(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:base'].orion;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var orion;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/orionjs_dictionary/dictionary.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Creates the dictionary mongo collection                                                                             // 2
 */                                                                                                                    // 3
orion.dictionary = new Mongo.Collection('dictionary');                                                                 // 4
                                                                                                                       // 5
/**                                                                                                                    // 6
 * To get reactively if the dictionary is active                                                                       // 7
 */                                                                                                                    // 8
orion.dictionary._isActiveDependency = new Tracker.Dependency();                                                       // 9
orion.dictionary._isActive = false;                                                                                    // 10
orion.dictionary.isActive = function() {                                                                               // 11
  this._isActiveDependency.depend();                                                                                   // 12
  return this._isActive;                                                                                               // 13
};                                                                                                                     // 14
                                                                                                                       // 15
/**                                                                                                                    // 16
 * Register dictionary actions and helpers for roles                                                                   // 17
 */                                                                                                                    // 18
Roles.registerAction('dictionary.update', true);                                                                       // 19
Roles.registerHelper('dictionary.allowedCategories', function() {                                                      // 20
  return orion.dictionary.simpleSchema()._firstLevelSchemaKeys;                                                        // 21
});                                                                                                                    // 22
                                                                                                                       // 23
/**                                                                                                                    // 24
 * Dictionary permissions                                                                                              // 25
 */                                                                                                                    // 26
orion.dictionary.deny({                                                                                                // 27
  /**                                                                                                                  // 28
   * No one can insert a dicionary object                                                                              // 29
   * becouse it only uses one and its created                                                                          // 30
   * automatically                                                                                                     // 31
   */                                                                                                                  // 32
  'insert': function(userId, doc) {                                                                                    // 33
    return true;                                                                                                       // 34
  },                                                                                                                   // 35
  /**                                                                                                                  // 36
   * No one can remove a dicionary object                                                                              // 37
   * becouse it only uses one.                                                                                         // 38
   */                                                                                                                  // 39
  'remove': function(userId, doc) {                                                                                    // 40
    return true;                                                                                                       // 41
  }                                                                                                                    // 42
});                                                                                                                    // 43
                                                                                                                       // 44
orion.dictionary.allow({                                                                                               // 45
  'update': function(userId, doc, fields, modifier) {                                                                  // 46
    return Roles.allow(userId, 'dictionary.update', userId, doc, fields, modifier);                                    // 47
  }                                                                                                                    // 48
});                                                                                                                    // 49
                                                                                                                       // 50
orion.dictionary.deny({                                                                                                // 51
  'update': function(userId, doc, fields, modifier) {                                                                  // 52
    return Roles.deny(userId, 'dictionary.update', userId, doc, fields, modifier);                                     // 53
  }                                                                                                                    // 54
});                                                                                                                    // 55
                                                                                                                       // 56
/**                                                                                                                    // 57
 * Only allow to edit allowed categories                                                                               // 58
 * If is set to false, can update all fields                                                                           // 59
 */                                                                                                                    // 60
orion.dictionary.deny({                                                                                                // 61
  update: function (userId, doc, fields, modifier) {                                                                   // 62
    var allowedFields = _.union.apply(this, Roles.helper(Meteor.userId(), 'dictionary.allowedCategories'));            // 63
    if (allowedFields === false && _.difference(fields, allowedFields).length > 0) {                                   // 64
      return true;                                                                                                     // 65
    }                                                                                                                  // 66
  }                                                                                                                    // 67
});                                                                                                                    // 68
                                                                                                                       // 69
/**                                                                                                                    // 70
 * Function to add a definition to the dictionary.                                                                     // 71
 * This just modifies the schema of the dictionary object                                                              // 72
 * and adds the form in the admin.                                                                                     // 73
 */                                                                                                                    // 74
orion.dictionary.addDefinition = function(name, category, attribute) {                                                 // 75
  var newSchema = (this.simpleSchema() && _.clone(this.simpleSchema()._schema)) || {};                                 // 76
                                                                                                                       // 77
  newSchema[category] = newSchema[category] || {                                                                       // 78
    type: Object,                                                                                                      // 79
    optional: true                                                                                                     // 80
  };                                                                                                                   // 81
                                                                                                                       // 82
  newSchema[category + '.' + name] = _.extend({                                                                        // 83
    optional: true                                                                                                     // 84
  }, attribute);                                                                                                       // 85
                                                                                                                       // 86
  this.attachSchema(new SimpleSchema(newSchema));                                                                      // 87
                                                                                                                       // 88
  if (!this._isActive) {                                                                                               // 89
    this._isActive = true;                                                                                             // 90
    this._isActiveDependency.changed();                                                                                // 91
  }                                                                                                                    // 92
};                                                                                                                     // 93
                                                                                                                       // 94
/**                                                                                                                    // 95
 * Returns the value of the definition.                                                                                // 96
 * If the definition doesn't exists it                                                                                 // 97
 * returns the defaultValue                                                                                            // 98
 */                                                                                                                    // 99
orion.dictionary.get = function(path, defaultValue) {                                                                  // 100
  // Sets empty string to avoid problems on templates                                                                  // 101
  defaultValue = !defaultValue || defaultValue instanceof Spacebars.kw ? undefined : defaultValue;                     // 102
                                                                                                                       // 103
  if (!defaultValue && orion.dictionary.simpleSchema()) {                                                              // 104
    var def = orion.dictionary.simpleSchema()._schema[path];                                                           // 105
    if (def && _.has(def, 'defaultValue')) {                                                                           // 106
      defaultValue = _.isFunction(def.defaultValue) ? def.defaultValue() : def.defaultValue;                           // 107
    }                                                                                                                  // 108
  }                                                                                                                    // 109
                                                                                                                       // 110
  return orion.helpers.searchObjectWithDots(this.findOne(), path) || defaultValue;                                     // 111
};                                                                                                                     // 112
                                                                                                                       // 113
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/orionjs_dictionary/admin.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Init the template name variable                                                                                     // 2
 */                                                                                                                    // 3
ReactiveTemplates.request('dictionaryUpdate');                                                                         // 4
                                                                                                                       // 5
/**                                                                                                                    // 6
 * Register the route                                                                                                  // 7
 */                                                                                                                    // 8
RouterLayer.route('/admin/dictionary', {                                                                               // 9
  layout: 'layout',                                                                                                    // 10
  template: 'dictionaryUpdate',                                                                                        // 11
  name: 'dictionary.update',                                                                                           // 12
  reactiveTemplates: true                                                                                              // 13
});                                                                                                                    // 14
                                                                                                                       // 15
/**                                                                                                                    // 16
 * Ensure user is logged in                                                                                            // 17
 */                                                                                                                    // 18
orion.accounts.addProtectedRoute('dictionary.update');                                                                 // 19
                                                                                                                       // 20
/**                                                                                                                    // 21
 * Register the link                                                                                                   // 22
 */                                                                                                                    // 23
Tracker.autorun(function () {                                                                                          // 24
  if (!orion.dictionary.isActive() || Meteor.isServer) return;                                                         // 25
                                                                                                                       // 26
  orion.links.add({                                                                                                    // 27
    index: 10,                                                                                                         // 28
    identifier: 'dictionary-update',                                                                                   // 29
    title: i18n('dictionary.update.title'),                                                                            // 30
    routeName: 'dictionary.update',                                                                                    // 31
    activeRouteRegex: 'dictionary',                                                                                    // 32
    permission: 'dictionary.update',                                                                                   // 33
  });                                                                                                                  // 34
});                                                                                                                    // 35
                                                                                                                       // 36
/**                                                                                                                    // 37
 * Create the template helpers for a dictionary                                                                        // 38
 */                                                                                                                    // 39
                                                                                                                       // 40
if (Meteor.isClient) {                                                                                                 // 41
                                                                                                                       // 42
  ReactiveTemplates.onRendered('dictionaryUpdate', function() {                                                        // 43
    var defaultCategory = _.first(_.union.apply(this, Roles.helper(Meteor.userId(), 'dictionary.allowedCategories')));
    Session.set('dictionaryUpdateCurrentCategory', defaultCategory);                                                   // 45
  });                                                                                                                  // 46
                                                                                                                       // 47
  ReactiveTemplates.events('dictionaryUpdate', {                                                                       // 48
    'click [data-category]': function(event) {                                                                         // 49
      var newCategory = $(event.currentTarget).attr('data-category');                                                  // 50
      Session.set('dictionaryUpdateCurrentCategory', newCategory);                                                     // 51
    }                                                                                                                  // 52
  });                                                                                                                  // 53
                                                                                                                       // 54
  ReactiveTemplates.helpers('dictionaryUpdate', {                                                                      // 55
    getDoc: function() {                                                                                               // 56
      return orion.dictionary.findOne();                                                                               // 57
    },                                                                                                                 // 58
    currentCategory: function() {                                                                                      // 59
      return Session.get('dictionaryUpdateCurrentCategory');                                                           // 60
    },                                                                                                                 // 61
    getCategories: function() {                                                                                        // 62
      return _.union.apply(this, Roles.helper(Meteor.userId(), 'dictionary.allowedCategories'));                       // 63
    }                                                                                                                  // 64
  });                                                                                                                  // 65
}                                                                                                                      // 66
                                                                                                                       // 67
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/orionjs_dictionary/dictionary_server.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * If its on server, inserts the dictionary object                                                                     // 2
 */                                                                                                                    // 3
if (orion.dictionary.find(process.env.ORION_APPID?{_id:process.env.ORION_APPID}:{}).count() === 0) {                   // 4
  // orion.dictionary.remove(process.env.ORION_APPID?{_id:process.env.ORION_APPID}:{});                                // 5
  orion.dictionary.insert(process.env.ORION_APPID?{_id:process.env.ORION_APPID}:{}, function(){                        // 6
    console.log("Orion dictionary initialized");                                                                       // 7
  });                                                                                                                  // 8
}                                                                                                                      // 9
                                                                                                                       // 10
/**                                                                                                                    // 11
 * Publications of the dictionary                                                                                      // 12
 */                                                                                                                    // 13
Meteor.publish('orion_dictionary', function() {                                                                        // 14
  return orion.dictionary.find(process.env.ORION_APPID?{_id:process.env.ORION_APPID}:{});                              // 15
});                                                                                                                    // 16
                                                                                                                       // 17
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:dictionary'] = {
  orion: orion
};

})();

//# sourceMappingURL=orionjs_dictionary.js.map
