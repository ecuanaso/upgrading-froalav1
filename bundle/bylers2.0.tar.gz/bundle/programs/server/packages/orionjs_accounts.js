(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:attributes'].orion;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;
var AccountsTemplates = Package['useraccounts:core'].AccountsTemplates;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var Inject = Package['meteorhacks:inject-initial'].Inject;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var i18n = Package['anti:i18n'].i18n;
var Autoupdate = Package.autoupdate.Autoupdate;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var Tabular, UsersEmailsSchema, UsersPasswordSchema, orion;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/tabular.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Tabular = null;                                                                                                   // 1
                                                                                                                  // 2
if (Package['nicolaslopezj:tabular-materialize']) {                                                               // 3
  Tabular = Package['nicolaslopezj:tabular-materialize'].Tabular;                                                 // 4
}                                                                                                                 // 5
                                                                                                                  // 6
if (Package['aldeed:tabular']) {                                                                                  // 7
  Tabular = Package['aldeed:tabular'].Tabular;                                                                    // 8
}                                                                                                                 // 9
                                                                                                                  // 10
if (!Tabular) {                                                                                                   // 11
  throw new Meteor.Error('orion', 'You must install tabular to use this package');                                // 12
}                                                                                                                 // 13
                                                                                                                  // 14
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/accounts.js                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
orion.accounts = {};                                                                                              // 1
                                                                                                                  // 2
/**                                                                                                               // 3
 * Initialize the profile schema option with its default value                                                    // 4
 */                                                                                                               // 5
Options.init('profileSchema', {                                                                                   // 6
  name: {                                                                                                         // 7
    type: String,                                                                                                 // 8
    label: orion.helpers.getTranslation('accounts.schema.profile.name')                                           // 9
  }                                                                                                               // 10
});                                                                                                               // 11
                                                                                                                  // 12
/**                                                                                                               // 13
 * Updates the profile schema reactively                                                                          // 14
 */                                                                                                               // 15
Tracker.autorun(function () {                                                                                     // 16
  orion.accounts.profileSchema = new SimpleSchema({                                                               // 17
    profile: {                                                                                                    // 18
      type: new SimpleSchema(Options.get('profileSchema'))                                                        // 19
    }                                                                                                             // 20
  });                                                                                                             // 21
});                                                                                                               // 22
                                                                                                                  // 23
/**                                                                                                               // 24
 * Initialize accounts options                                                                                    // 25
 * If there is no admin, we allow to create accounts                                                              // 26
 */                                                                                                               // 27
Options.init('defaultRoles', []);                                                                                 // 28
Options.init('forbidClientAccountCreation', true);                                                                // 29
                                                                                                                  // 30
/**                                                                                                               // 31
 * We will use listen instead of tracker because on client tracker starts after meteor.startup                    // 32
 */                                                                                                               // 33
Options.listen('forbidClientAccountCreation', function(value) {                                                   // 34
  AccountsTemplates.configure({                                                                                   // 35
    forbidClientAccountCreation: orion.adminExists && value,                                                      // 36
  });                                                                                                             // 37
});                                                                                                               // 38
                                                                                                                  // 39
/**                                                                                                               // 40
 * Adds the "name" field to the sign up form                                                                      // 41
 */                                                                                                               // 42
AccountsTemplates.addField({                                                                                      // 43
  _id: 'name',                                                                                                    // 44
  type: 'text',                                                                                                   // 45
  displayName: Meteor.isClient ? i18n('accounts.register.fields.name') : 'Name',                                  // 46
  placeholder: Meteor.isClient ? i18n('accounts.register.fields.name') : 'Your Name',                             // 47
  required: true,                                                                                                 // 48
});                                                                                                               // 49
                                                                                                                  // 50
UsersEmailsSchema = new SimpleSchema({                                                                            // 51
  emails: {                                                                                                       // 52
    type: [Object],                                                                                               // 53
    optional: true,                                                                                               // 54
    label: orion.helpers.getTranslation('accounts.schema.emails.title')                                           // 55
  },                                                                                                              // 56
  'emails.$.address': {                                                                                           // 57
    type: String,                                                                                                 // 58
    regEx: SimpleSchema.RegEx.Email,                                                                              // 59
    label: orion.helpers.getTranslation('accounts.schema.emails.address')                                         // 60
  },                                                                                                              // 61
  'emails.$.verified': {                                                                                          // 62
    type: Boolean,                                                                                                // 63
    label: orion.helpers.getTranslation('accounts.schema.emails.verified')                                        // 64
  }                                                                                                               // 65
});                                                                                                               // 66
                                                                                                                  // 67
SimpleSchema.messages({                                                                                           // 68
  'passwordMismatch': i18n('global.passwordNotMatch')                                                             // 69
});                                                                                                               // 70
                                                                                                                  // 71
UsersPasswordSchema = new SimpleSchema({                                                                          // 72
  password: {                                                                                                     // 73
    type: String,                                                                                                 // 74
    label: orion.helpers.getTranslation('accounts.schema.password.new'),                                          // 75
    min: 8,                                                                                                       // 76
    autoform: {                                                                                                   // 77
      type: 'password'                                                                                            // 78
    }                                                                                                             // 79
  },                                                                                                              // 80
  confirm: {                                                                                                      // 81
    type: String,                                                                                                 // 82
    label: orion.helpers.getTranslation('accounts.schema.password.confirm'),                                      // 83
    min: 8,                                                                                                       // 84
    autoform: {                                                                                                   // 85
      type: 'password'                                                                                            // 86
    },                                                                                                            // 87
    custom: function () {                                                                                         // 88
      if (this.value !== this.field('password').value) {                                                          // 89
        return 'passwordMismatch';                                                                                // 90
      }                                                                                                           // 91
    }                                                                                                             // 92
  },                                                                                                              // 93
});                                                                                                               // 94
                                                                                                                  // 95
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/authentication/login.js                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               // 1
 * Init the template name variable                                                                                // 2
 */                                                                                                               // 3
ReactiveTemplates.request('login');                                                                               // 4
                                                                                                                  // 5
RouterLayer.route('/admin/login', {                                                                               // 6
  name: 'admin.login',                                                                                            // 7
  layout: 'outAdminLayout',                                                                                       // 8
  template: 'login',                                                                                              // 9
  reactiveTemplates: true                                                                                         // 10
});                                                                                                               // 11
                                                                                                                  // 12
if (Meteor.isClient) {                                                                                            // 13
  ReactiveTemplates.onRendered('login', function() {                                                              // 14
    this.autorun(function() {                                                                                     // 15
      if (Meteor.userId()) {                                                                                      // 16
        var ref = RouterLayer.getQueryParam('ref') || RouterLayer.pathFor('admin');                               // 17
        RouterLayer.go(ref);                                                                                      // 18
      }                                                                                                           // 19
    });                                                                                                           // 20
  });                                                                                                             // 21
}                                                                                                                 // 22
                                                                                                                  // 23
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/authentication/secure-routes.js                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               // 1
 * To set the secure routes                                                                                       // 2
 */                                                                                                               // 3
Options.init('ensureSignedIn', []);                                                                               // 4
                                                                                                                  // 5
Tracker.autorun(function () {                                                                                     // 6
  if (!Meteor.isClient) return;                                                                                   // 7
  var routes = Options.get('ensureSignedIn');                                                                     // 8
  if (RouterLayer.router == 'iron-router') {                                                                      // 9
    RouterLayer.ironRouter.onBeforeAction(function() {                                                            // 10
      if (RouterLayer.ironRouter.current && _.contains(routes, RouterLayer.ironRouter.current().route.getName()) && !Meteor.userId()) {
        var path = null;                                                                                          // 12
        Tracker.nonreactive(function() {                                                                          // 13
          path = RouterLayer.ironRouter.current().location.get().path                                             // 14
        });                                                                                                       // 15
        this.router.go('admin.login', { }, { replaceState: true, query: { ref: path } });                         // 16
        return;                                                                                                   // 17
      }                                                                                                           // 18
      this.next();                                                                                                // 19
    });                                                                                                           // 20
  } else if (RouterLayer.router == 'flow-router') {                                                               // 21
    RouterLayer.flowRouter.triggers.enter([function(context, redirect) {                                          // 22
      Tracker.autorun(function() {                                                                                // 23
        if (_.contains(routes, RouterLayer.flowRouter.getRouteName()) && !Meteor.userId()) {                      // 24
          FlowRouter.withReplaceState(function() {                                                                // 25
            RouterLayer.flowRouter.go('admin.login', {}, { ref: FlowRouter.current().path });                     // 26
          });                                                                                                     // 27
        }                                                                                                         // 28
      });                                                                                                         // 29
    }]);                                                                                                          // 30
  }                                                                                                               // 31
});                                                                                                               // 32
                                                                                                                  // 33
orion.accounts.addProtectedRoute = function(routeName) {                                                          // 34
  Options.arrayPush('ensureSignedIn', routeName);                                                                 // 35
};                                                                                                                // 36
                                                                                                                  // 37
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/my-account/admin.js                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               // 1
 * Display account settings                                                                                       // 2
 */                                                                                                               // 3
ReactiveTemplates.request('myAccount.index');                                                                     // 4
ReactiveTemplates.request('myAccount.password');                                                                  // 5
ReactiveTemplates.request('myAccount.profile');                                                                   // 6
                                                                                                                  // 7
/**                                                                                                               // 8
 * Register the route                                                                                             // 9
 */                                                                                                               // 10
RouterLayer.route('/admin/my-account', {                                                                          // 11
  layout: 'layout',                                                                                               // 12
  template: 'myAccount.index',                                                                                    // 13
  name: 'myAccount.index',                                                                                        // 14
  reactiveTemplates: true                                                                                         // 15
});                                                                                                               // 16
orion.accounts.addProtectedRoute('myAccount.index');                                                              // 17
                                                                                                                  // 18
/**                                                                                                               // 19
 * Allow password change                                                                                          // 20
 */                                                                                                               // 21
AccountsTemplates.configure({                                                                                     // 22
  enablePasswordChange: true                                                                                      // 23
});                                                                                                               // 24
                                                                                                                  // 25
/**                                                                                                               // 26
 * Register the route                                                                                             // 27
 */                                                                                                               // 28
RouterLayer.route('/admin/my-account/change-password', {                                                          // 29
  layout: 'layout',                                                                                               // 30
  template: 'myAccount.password',                                                                                 // 31
  name: 'myAccount.password',                                                                                     // 32
  reactiveTemplates: true                                                                                         // 33
});                                                                                                               // 34
orion.accounts.addProtectedRoute('myAccount.password');                                                           // 35
                                                                                                                  // 36
/**                                                                                                               // 37
 * To update the profile                                                                                          // 38
 */                                                                                                               // 39
RouterLayer.route('/admin/my-account/profile', {                                                                  // 40
  layout: 'layout',                                                                                               // 41
  template: 'myAccount.profile',                                                                                  // 42
  name: 'myAccount.profile',                                                                                      // 43
  reactiveTemplates: true                                                                                         // 44
});                                                                                                               // 45
orion.accounts.addProtectedRoute('myAccount.profile');                                                            // 46
                                                                                                                  // 47
/**                                                                                                               // 48
 * Create the template events account settings                                                                    // 49
 */                                                                                                               // 50
if (Meteor.isClient) {                                                                                            // 51
  /**                                                                                                             // 52
   * Register the link                                                                                            // 53
   */                                                                                                             // 54
  Tracker.autorun(function () {                                                                                   // 55
    orion.links.add({                                                                                             // 56
      identifier: 'myAccount',                                                                                    // 57
      title: (Meteor.user() && Meteor.user().profile && Meteor.user().profile.name) || 'Account',                 // 58
      activeRouteRegex: 'myAccount'                                                                               // 59
    });                                                                                                           // 60
    orion.links.add({                                                                                             // 61
      index: 20,                                                                                                  // 62
      identifier: 'myAccount-index',                                                                              // 63
      parent: 'myAccount',                                                                                        // 64
      title: i18n('accounts.myAccount.title'),                                                                    // 65
      routeName: 'myAccount.index',                                                                               // 66
      activeRouteRegex: 'myAccount.index'                                                                         // 67
    });                                                                                                           // 68
    orion.links.add({                                                                                             // 69
      index: 50,                                                                                                  // 70
      identifier: 'myAccount-updateProfile',                                                                      // 71
      parent: 'myAccount',                                                                                        // 72
      title: i18n('accounts.updateProfile.title'),                                                                // 73
      routeName: 'myAccount.profile',                                                                             // 74
      activeRouteRegex: 'myAccount.profile'                                                                       // 75
    });                                                                                                           // 76
    orion.links.add({                                                                                             // 77
      index: 100,                                                                                                 // 78
      identifier: 'myAccount-changePassword',                                                                     // 79
      parent: 'myAccount',                                                                                        // 80
      title: i18n('accounts.changePassword.title'),                                                               // 81
      routeName: 'myAccount.password',                                                                            // 82
      activeRouteRegex: 'myAccount.password'                                                                      // 83
    });                                                                                                           // 84
  });                                                                                                             // 85
                                                                                                                  // 86
  ReactiveTemplates.events('myAccount.index', {                                                                   // 87
    'click .logout': function() {                                                                                 // 88
      return Meteor.logout();                                                                                     // 89
    }                                                                                                             // 90
  });                                                                                                             // 91
                                                                                                                  // 92
  ReactiveTemplates.helpers('myAccount.profile', {                                                                // 93
    getDoc: function() {                                                                                          // 94
      return Meteor.user();                                                                                       // 95
    },                                                                                                            // 96
    getSchema: function() {                                                                                       // 97
      return orion.accounts.profileSchema;                                                                        // 98
    }                                                                                                             // 99
  });                                                                                                             // 100
}                                                                                                                 // 101
                                                                                                                  // 102
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/accounts-tab/accounts.js                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               // 1
 * Register the account index action                                                                              // 2
 */                                                                                                               // 3
Roles.registerAction('accounts.index', true);                                                                     // 4
                                                                                                                  // 5
/**                                                                                                               // 6
 * Can the user update user users roles?                                                                          // 7
 */                                                                                                               // 8
Roles.registerAction('accounts.update.roles', true);                                                              // 9
Roles.registerAction('accounts.update.password', true);                                                           // 10
Roles.registerAction('accounts.update.emails', true);                                                             // 11
Roles.registerAction('accounts.update.profile', true);                                                            // 12
Roles.registerAction('accounts.remove', true);                                                                    // 13
                                                                                                                  // 14
/**                                                                                                               // 15
 * Register the index filter for the accounts.list                                                                // 16
 */                                                                                                               // 17
Roles.registerHelper('accounts.indexFilter', {});                                                                 // 18
                                                                                                                  // 19
/**                                                                                                               // 20
 * To set the actions for the admin                                                                               // 21
 */                                                                                                               // 22
orion.accounts._adminUsersButtons = [];                                                                           // 23
                                                                                                                  // 24
/**                                                                                                               // 25
 * Add buttons to the list of users in the admin                                                                  // 26
 */                                                                                                               // 27
orion.accounts.addAdminUsersButton = function(button) {                                                           // 28
  Tracker.nonreactive(function () {                                                                               // 29
    var current = _.findWhere(orion.accounts._adminUsersButtons, {                                                // 30
      route: button.route,                                                                                        // 31
      meteorMethod: button.meteorMethod,                                                                          // 32
    });                                                                                                           // 33
    if (current) {                                                                                                // 34
      orion.accounts._adminUsersButtons = _.without(orion.accounts._adminUsersButtons, current);                  // 35
    }                                                                                                             // 36
  });                                                                                                             // 37
                                                                                                                  // 38
  check(button, {                                                                                                 // 39
    title: String,                                                                                                // 40
    route: Match.Optional(String),                                                                                // 41
    meteorMethod: Match.Optional(String),                                                                         // 42
    shouldShow: Match.Optional(Function)                                                                          // 43
  });                                                                                                             // 44
                                                                                                                  // 45
  orion.accounts._adminUsersButtons.push(button);                                                                 // 46
};                                                                                                                // 47
                                                                                                                  // 48
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/accounts-tab/admin.js                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               // 1
 * Display account settings                                                                                       // 2
 */                                                                                                               // 3
ReactiveTemplates.request('accounts.index');                                                                      // 4
ReactiveTemplates.request('accounts.update');                                                                     // 5
                                                                                                                  // 6
/**                                                                                                               // 7
 * Register the route                                                                                             // 8
 */                                                                                                               // 9
RouterLayer.route('/admin/accounts', {                                                                            // 10
  layout: 'layout',                                                                                               // 11
  template: 'accounts.index',                                                                                     // 12
  name: 'accounts.index',                                                                                         // 13
  reactiveTemplates: true                                                                                         // 14
});                                                                                                               // 15
orion.accounts.addProtectedRoute('accounts.index');                                                               // 16
                                                                                                                  // 17
/**                                                                                                               // 18
 * Register the link                                                                                              // 19
 */                                                                                                               // 20
if (Meteor.isClient) {                                                                                            // 21
  Tracker.autorun(function () {                                                                                   // 22
    orion.links.add({                                                                                             // 23
      index: 80,                                                                                                  // 24
      identifier: 'accounts-index',                                                                               // 25
      title: i18n('accounts.index.title'),                                                                        // 26
      routeName: 'accounts.index',                                                                                // 27
      activeRouteRegex: 'accounts',                                                                               // 28
      permission: 'accounts.index'                                                                                // 29
    });                                                                                                           // 30
  });                                                                                                             // 31
}                                                                                                                 // 32
                                                                                                                  // 33
/**                                                                                                               // 34
 * Tabular table                                                                                                  // 35
 */                                                                                                               // 36
var tabularOptions = {                                                                                            // 37
  name: 'AccountsIndex',                                                                                          // 38
  collection: Meteor.users,                                                                                       // 39
  allow: function (userId) {                                                                                      // 40
    return Roles.userHasPermission(userId, 'accounts.index'); // don't allow this person to subscribe to the data
  },                                                                                                              // 42
  selector: function(userId) {                                                                                    // 43
    var selectors = Roles.helper(userId, 'accounts.indexFilter');                                                 // 44
    return { $or: selectors };                                                                                    // 45
  },                                                                                                              // 46
  pub: 'adminAccountsIndexTabular',                                                                               // 47
  columns: [                                                                                                      // 48
    {                                                                                                             // 49
      data: 'profile.name',                                                                                       // 50
      title: orion.helpers.getTranslation('accounts.index.tableTitles.name'),                                     // 51
      render: function(val, type, doc) {                                                                          // 52
        return val ? val : '<span class="grey-text help-block">' + i18n('accounts.index.noName') + '</span>';     // 53
      }                                                                                                           // 54
    },                                                                                                            // 55
    {                                                                                                             // 56
      data: 'usedServices',                                                                                       // 57
      title: orion.helpers.getTranslation('accounts.index.tableTitles.services'),                                 // 58
      render: function(val, type, doc) {                                                                          // 59
        var services = _.without(val, 'email', 'resume');                                                         // 60
        if (!services.length) {                                                                                   // 61
          var title = i18n('accounts.index.actions.sendEnrollmentEmail');                                         // 62
          return '<button class="btn btn-danger red btn-xs send-enrollment-email-btn" data-user="' + doc._id + '">' + title + '</button>';
        }                                                                                                         // 64
        return services.map(function(service) {                                                                   // 65
          return '<span class="label label-primary blue">' + service + '</span>';                                 // 66
        }).join('');                                                                                              // 67
      }                                                                                                           // 68
    },                                                                                                            // 69
    {                                                                                                             // 70
      data: 'emails',                                                                                             // 71
      title: orion.helpers.getTranslation('accounts.index.tableTitles.email'),                                    // 72
      render: function(val, type, doc) {                                                                          // 73
        return val && val[0] && val[0].address;                                                                   // 74
      }                                                                                                           // 75
    },                                                                                                            // 76
    {                                                                                                             // 77
      data: 'roles()',                                                                                            // 78
      title: orion.helpers.getTranslation('accounts.index.tableTitles.roles'),                                    // 79
      render: function(val, type, doc) {                                                                          // 80
        return val.map(function(role) {                                                                           // 81
          return '<span class="label label-danger red">' + role + '</span>';                                      // 82
        }).join('');                                                                                              // 83
      }                                                                                                           // 84
    },                                                                                                            // 85
    {                                                                                                             // 86
      title: orion.helpers.getTranslation('accounts.index.tableTitles.actions'),                                  // 87
      render: function(val, type, doc) {                                                                          // 88
        return _.filter(orion.accounts._adminUsersButtons, function(value, key, list){                            // 89
          if (typeof value.shouldShow != 'function') {                                                            // 90
            return true;                                                                                          // 91
          }                                                                                                       // 92
          return value.shouldShow(doc);                                                                           // 93
        }).map(function(button, index) {                                                                          // 94
          return '<a class="btn btn-default btn-xs waves-effect waves-light light-blue accent-4 user-btn-action" data-button-index="' + index + '" data-user="' + doc._id + '">' + button.title + '</a>';
        }).join('');                                                                                              // 96
      }                                                                                                           // 97
    }                                                                                                             // 98
  ]                                                                                                               // 99
};                                                                                                                // 100
                                                                                                                  // 101
Tracker.autorun(function () {                                                                                     // 102
  tabularOptions.columns.map(function (column) {                                                                  // 103
    if (_.isFunction(column.title)) {                                                                             // 104
      column.langTitle = column.title;                                                                            // 105
    }                                                                                                             // 106
    if (_.isFunction(column.langTitle)) {                                                                         // 107
      column.title = column.langTitle();                                                                          // 108
    }                                                                                                             // 109
    return column;                                                                                                // 110
  });                                                                                                             // 111
  orion.accounts.indexTabularTable = new Tabular.Table(tabularOptions);                                           // 112
});                                                                                                               // 113
                                                                                                                  // 114
/**                                                                                                               // 115
 * Edit user                                                                                                      // 116
 */                                                                                                               // 117
RouterLayer.route('/admin/accounts/:_id/update', {                                                                // 118
  layout: 'layout',                                                                                               // 119
  template: 'accounts.update',                                                                                    // 120
  name: 'accounts.update',                                                                                        // 121
  reactiveTemplates: true                                                                                         // 122
});                                                                                                               // 123
orion.accounts.addProtectedRoute('accounts.update');                                                              // 124
                                                                                                                  // 125
if (Meteor.isClient) {                                                                                            // 126
  Tracker.autorun(function () {                                                                                   // 127
    orion.accounts.addAdminUsersButton({                                                                          // 128
      title: i18n('accounts.index.actions.edit'),                                                                 // 129
      route: 'accounts.update',                                                                                   // 130
      shouldShow: function() {                                                                                    // 131
        return Roles.userHasPermission(Meteor.userId(), 'accounts.update.roles');                                 // 132
      }                                                                                                           // 133
    });                                                                                                           // 134
  });                                                                                                             // 135
}                                                                                                                 // 136
                                                                                                                  // 137
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/create/invite.js                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               // 1
 * Can the user update user users roles?                                                                          // 2
 */                                                                                                               // 3
Roles.registerAction('accounts.showCreate', true);                                                                // 4
Roles.registerAction('accounts.create', true);                                                                    // 5
Roles.registerHelper('accounts.allowedRoles', function() {                                                        // 6
  return Roles.availableRoles();                                                                                  // 7
});                                                                                                               // 8
                                                                                                                  // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/create/admin.js                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               // 1
 * invite users                                                                                                   // 2
 */                                                                                                               // 3
ReactiveTemplates.request('accounts.create');                                                                     // 4
                                                                                                                  // 5
RouterLayer.route('/admin/accounts/create', {                                                                     // 6
  layout: 'layout',                                                                                               // 7
  template: 'accounts.create',                                                                                    // 8
  name: 'accounts.create',                                                                                        // 9
  reactiveTemplates: true                                                                                         // 10
});                                                                                                               // 11
orion.accounts.addProtectedRoute('accounts.create');                                                              // 12
                                                                                                                  // 13
if (Meteor.isClient) {                                                                                            // 14
  ReactiveTemplates.onRendered('accounts.create', function() {                                                    // 15
    Session.set('accounts.create.invitationId', null);                                                            // 16
    Session.set('accounts.create.method', 'invitation');                                                          // 17
  });                                                                                                             // 18
  ReactiveTemplates.helpers('accounts.create', {                                                                  // 19
    roles: function() {                                                                                           // 20
      return _.union.apply(this, Roles.helper(Meteor.userId(), 'accounts.allowedRoles'));                         // 21
    },                                                                                                            // 22
    invitationId: function() {                                                                                    // 23
      return Session.get('accounts.create.invitationId');                                                         // 24
    },                                                                                                            // 25
    email: function() {                                                                                           // 26
      return Session.get('accounts.create.email');                                                                // 27
    },                                                                                                            // 28
    createWithInvitation: function() {                                                                            // 29
      return Session.get('accounts.create.method') == 'invitation';                                               // 30
    }                                                                                                             // 31
  });                                                                                                             // 32
  ReactiveTemplates.events('accounts.create', {                                                                   // 33
    'submit form.create': function (event, template) {                                                            // 34
      var roles = [];                                                                                             // 35
      template.$('input[role]').each(function(index, val) {                                                       // 36
         var role = $(this).attr('role');                                                                         // 37
         if ($(this).is(':checked')) {                                                                            // 38
          roles.push(role);                                                                                       // 39
         }                                                                                                        // 40
      });                                                                                                         // 41
                                                                                                                  // 42
      var email = template.$('input[type="email"]').val();                                                        // 43
      var method = template.$('input[name="createMethod"]:checked').val();                                        // 44
      var options = {};                                                                                           // 45
                                                                                                                  // 46
      if (method == 'invitation') {                                                                               // 47
        options = {                                                                                               // 48
          email: email,                                                                                           // 49
          roles: roles                                                                                            // 50
        };                                                                                                        // 51
      } else if (method == 'now') {                                                                               // 52
        var name = template.$('input[name="name"]').val();                                                        // 53
        var password = template.$('input[name="password"]').val();                                                // 54
        var confirm = template.$('input[name="confirm"]').val();                                                  // 55
        if (password != confirm) {                                                                                // 56
          alert(i18n('global.passwordNotMatch'));                                                                 // 57
          return false;                                                                                           // 58
        }                                                                                                         // 59
        options = {                                                                                               // 60
          email: email,                                                                                           // 61
          password: password,                                                                                     // 62
          name: name,                                                                                             // 63
          roles: roles                                                                                            // 64
        };                                                                                                        // 65
      }                                                                                                           // 66
                                                                                                                  // 67
      Meteor.call('accountsCreateUser', options, function(error, result) {                                        // 68
        if (error) {                                                                                              // 69
          alert(error.reason);                                                                                    // 70
          console.log(error);                                                                                     // 71
        } else {                                                                                                  // 72
          RouterLayer.go('accounts.index');                                                                       // 73
        }                                                                                                         // 74
      });                                                                                                         // 75
      return false;                                                                                               // 76
    },                                                                                                            // 77
    'change input[name="createMethod"]': function(event, template) {                                              // 78
      Session.set('accounts.create.method', $(event.currentTarget).val());                                        // 79
    },                                                                                                            // 80
    'click .btn-invite-another': function() {                                                                     // 81
      Session.set('accounts.create.invitationId', null);                                                          // 82
    }                                                                                                             // 83
  });                                                                                                             // 84
}                                                                                                                 // 85
                                                                                                                  // 86
/**                                                                                                               // 87
 * Register with invitation                                                                                       // 88
 */                                                                                                               // 89
ReactiveTemplates.request('registerWithInvitation');                                                              // 90
RouterLayer.route('/register/invitation/:_id', {                                                                  // 91
  layout: 'outAdminLayout',                                                                                       // 92
  template: 'registerWithInvitation',                                                                             // 93
  name: 'registerWithInvitation',                                                                                 // 94
  reactiveTemplates: true                                                                                         // 95
});                                                                                                               // 96
                                                                                                                  // 97
if (Meteor.isClient) {                                                                                            // 98
                                                                                                                  // 99
  ReactiveTemplates.onRendered('registerWithInvitation', function() {                                             // 100
    if (Meteor.userId()) {                                                                                        // 101
      RouterLayer.go('admin');                                                                                    // 102
    }                                                                                                             // 103
    this.subscribe('invitation', RouterLayer.getParam('_id'));                                                    // 104
    Session.set('registerWithInvitationError', null);                                                             // 105
  });                                                                                                             // 106
                                                                                                                  // 107
  ReactiveTemplates.helpers('registerWithInvitation', {                                                           // 108
    invitation: function() {                                                                                      // 109
      return orion.accounts.invitations.findOne(RouterLayer.getParam('_id'));                                     // 110
    },                                                                                                            // 111
    error: function() {                                                                                           // 112
      return Session.get('registerWithInvitationError');                                                          // 113
    }                                                                                                             // 114
  });                                                                                                             // 115
                                                                                                                  // 116
  ReactiveTemplates.events('registerWithInvitation', {                                                            // 117
    'submit form': function (event, template) {                                                                   // 118
      event.preventDefault();                                                                                     // 119
      Session.set('registerWithInvitationError', null);                                                           // 120
                                                                                                                  // 121
      var email = template.$("[name='email']").val(),                                                             // 122
        name = template.$("[name='name']").val(),                                                                 // 123
        password = template.$("[name='password']").val(),                                                         // 124
        passwordConfirm = template.$("[name='password-confirm']").val();                                          // 125
                                                                                                                  // 126
      if (!/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email)) {
        Session.set('registerWithInvitationError', i18n('accounts.register.messages.invalidEmail'));              // 128
        return;                                                                                                   // 129
      }                                                                                                           // 130
                                                                                                                  // 131
      if (password != passwordConfirm) {                                                                          // 132
        Session.set('registerWithInvitationError', i18n('global.passwordNotMatch'));                              // 133
        return;                                                                                                   // 134
      }                                                                                                           // 135
                                                                                                                  // 136
      Meteor.call('registerWithInvitation', {                                                                     // 137
        invitationId: Router.current().params._id,                                                                // 138
        email: email,                                                                                             // 139
        password: password,                                                                                       // 140
        name: name                                                                                                // 141
      }, function(error, result) {                                                                                // 142
        if (error) {                                                                                              // 143
          Session.set('registerWithInvitationError', error.reason);                                               // 144
          console.log(error);                                                                                     // 145
        } else {                                                                                                  // 146
          Meteor.loginWithPassword(email, password, function(error) {                                             // 147
            if (error) {                                                                                          // 148
              Session.set('registerWithInvitationError', error.reason);                                           // 149
              console.log(error);                                                                                 // 150
            } else {                                                                                              // 151
              RouterLayer.go('admin');                                                                            // 152
            }                                                                                                     // 153
          });                                                                                                     // 154
        }                                                                                                         // 155
      });                                                                                                         // 156
    }                                                                                                             // 157
  });                                                                                                             // 158
}                                                                                                                 // 159
                                                                                                                  // 160
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/accounts_server.js                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               // 1
 * Sets the default permissions to new users                                                                      // 2
 */                                                                                                               // 3
Meteor.users.after.insert(function (userId, doc) {                                                                // 4
  var curUserId = doc._id;                                                                                        // 5
                                                                                                                  // 6
  if (orion.adminExists) {                                                                                        // 7
    // if there is a admin created we will set the default roles.                                                 // 8
                                                                                                                  // 9
    if (Roles._collection.find({ userId: curUserId }).count() === 0) {                                            // 10
      var defaultRoles = Options.get('defaultRoles');                                                             // 11
      Roles.addUserToRoles(curUserId, defaultRoles);                                                              // 12
    }                                                                                                             // 13
  } else {                                                                                                        // 14
    // If there is no admin, we will add the admin role to this new user.                                         // 15
    Roles.addUserToRoles(curUserId, 'admin');                                                                     // 16
    // Pass to the client if the admin exists                                                                     // 17
    orion.adminExists = true;                                                                                     // 18
    Inject.obj('adminExists', { exists: true });                                                                  // 19
  }                                                                                                               // 20
});                                                                                                               // 21
                                                                                                                  // 22
                                                                                                                  // 23
/**                                                                                                               // 24
 * Pass to the client if there is a admin account                                                                 // 25
 */                                                                                                               // 26
orion.adminExists = Roles._collection.find({ roles: 'admin' }).count() !== 0;                                     // 27
Inject.obj('adminExists', { exists: orion.adminExists });                                                         // 28
AccountsTemplates.configure({                                                                                     // 29
  forbidClientAccountCreation: !!orion.adminExists                                                                // 30
});                                                                                                               // 31
                                                                                                                  // 32
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/accounts-tab/server.js                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish('adminAccountsIndexTabular', function (tableName, ids, fields) {                                   // 1
  check(tableName, String);                                                                                       // 2
  check(ids, Array);                                                                                              // 3
  check(fields, Match.Optional(Object));                                                                          // 4
                                                                                                                  // 5
  if (!Roles.userHasPermission(this.userId, 'accounts.index')) {                                                  // 6
    return [];                                                                                                    // 7
  }                                                                                                               // 8
                                                                                                                  // 9
  var self = this;                                                                                                // 10
  var transform = function(user) {                                                                                // 11
    user.usedServices = _.keys(user.services);                                                                    // 12
    delete user.services;                                                                                         // 13
    return user;                                                                                                  // 14
  };                                                                                                              // 15
                                                                                                                  // 16
  fields.services = 1;                                                                                            // 17
  var usersHandle = Meteor.users.find({ _id: { $in: ids } }, { fields: fields }).observe({                        // 18
    added: function (user) {                                                                                      // 19
      self.added('users', user._id, transform(user));                                                             // 20
    },                                                                                                            // 21
    changed: function (user) {                                                                                    // 22
      self.changed('users', user._id, transform(user));                                                           // 23
    },                                                                                                            // 24
    removed: function (user) {                                                                                    // 25
      self.removed('users', user._id);                                                                            // 26
    }                                                                                                             // 27
  });                                                                                                             // 28
                                                                                                                  // 29
  self.onStop(function() {                                                                                        // 30
    usersHandle.stop();                                                                                           // 31
  });                                                                                                             // 32
                                                                                                                  // 33
  var rolesHandle = Roles._collection.find({ userId: { $in: ids } }).observe({                                    // 34
    added: function (role) {                                                                                      // 35
      self.added('roles', role._id, role);                                                                        // 36
    },                                                                                                            // 37
    changed: function (role) {                                                                                    // 38
      self.changed('roles', role._id, role);                                                                      // 39
    },                                                                                                            // 40
    removed: function (role) {                                                                                    // 41
      self.removed('roles', role._id);                                                                            // 42
    }                                                                                                             // 43
  });                                                                                                             // 44
                                                                                                                  // 45
  self.onStop(function() {                                                                                        // 46
    rolesHandle.stop();                                                                                           // 47
  });                                                                                                             // 48
                                                                                                                  // 49
  self.ready();                                                                                                   // 50
});                                                                                                               // 51
                                                                                                                  // 52
Meteor.publish('adminAccountsUpdateRoles', function (userId) {                                                    // 53
  check(userId, String);                                                                                          // 54
  if (!Roles.userHasPermission(this.userId, 'accounts.update.roles')) {                                           // 55
    return [];                                                                                                    // 56
  }                                                                                                               // 57
  return [                                                                                                        // 58
    Meteor.users.find(userId), // , { fields: { services: 0 } }),                                                 // 59
    Roles._collection.find({ userId: userId })                                                                    // 60
  ];                                                                                                              // 61
});                                                                                                               // 62
                                                                                                                  // 63
Meteor.methods({                                                                                                  // 64
  updateRoles: function (userId, roles) {                                                                         // 65
    check(userId, String);                                                                                        // 66
    check(roles, Array);                                                                                          // 67
    if (!Roles.userHasPermission(this.userId, 'accounts.update.roles')) {                                         // 68
      throw new Meteor.Error('unauthorized', i18n('accounts.update.messages.noPermissions'));                     // 69
    }                                                                                                             // 70
    Roles.setUserRoles(userId, roles);                                                                            // 71
  },                                                                                                              // 72
  orionAccountsUpdatePassword: function(modifier, userId) {                                                       // 73
    if (!Roles.userHasPermission(this.userId, 'accounts.update.password', userId)) {                              // 74
      throw new Meteor.Error('unauthorized', i18n('accounts.update.messages.noPermissions'));                     // 75
    }                                                                                                             // 76
    var options = modifier.$set;                                                                                  // 77
    check(options, UsersPasswordSchema);                                                                          // 78
    Accounts.setPassword(userId, options.password, { logout: true });                                             // 79
  },                                                                                                              // 80
  orionAccountsUpdateEmails: function(modifier, userId) {                                                         // 81
    if (!Roles.userHasPermission(this.userId, 'accounts.update.emails', userId)) {                                // 82
      throw new Meteor.Error('unauthorized', i18n('accounts.update.messages.noPermissions'));                     // 83
    }                                                                                                             // 84
    Meteor.users.update(userId, modifier);                                                                        // 85
  },                                                                                                              // 86
  orionAccountsUpdateProfile: function(modifier, userId) {                                                        // 87
    if (!Roles.userHasPermission(this.userId, 'accounts.update.profile', userId)) {                               // 88
      throw new Meteor.Error('unauthorized', i18n('accounts.update.messages.noPermissions'));                     // 89
    }                                                                                                             // 90
    Meteor.users.update(userId, modifier);                                                                        // 91
  },                                                                                                              // 92
  removeUser: function(userId){                                                                                   // 93
    check(userId, String);                                                                                        // 94
    if (!Roles.userHasPermission(this.userId, 'accounts.remove', userId)) {                                       // 95
      throw new Meteor.Error('unauthorized', i18n('accounts.update.messages.noPermissions'));                     // 96
    }                                                                                                             // 97
    Meteor.users.remove({ _id: userId });                                                                         // 98
  },                                                                                                              // 99
  adminSendEnrollmentEmail: function(userId) {                                                                    // 100
    check(userId, String);                                                                                        // 101
    Roles.checkPermission(this.userId, 'accounts.index');                                                         // 102
    return Accounts.sendEnrollmentEmail(userId);                                                                  // 103
  }                                                                                                               // 104
});                                                                                                               // 105
                                                                                                                  // 106
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/orionjs_accounts/create/server.js                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({                                                                                                  // 1
  accountsCreateUser: function(options) {                                                                         // 2
    check(options, {                                                                                              // 3
      email: String,                                                                                              // 4
      password: Match.Optional(String),                                                                           // 5
      name: Match.Optional(String),                                                                               // 6
      roles: [String]                                                                                             // 7
    });                                                                                                           // 8
                                                                                                                  // 9
    if (!Roles.userHasPermission(Meteor.userId(), 'accounts.create')) {                                           // 10
      throw new Meteor.Error('unauthorized', i18n('accounts.update.messages.noPermissions'));                     // 11
    }                                                                                                             // 12
                                                                                                                  // 13
    var newUser = { email: options.email };                                                                       // 14
    if (options.password) {                                                                                       // 15
      newUser.password = options.password;                                                                        // 16
    }                                                                                                             // 17
                                                                                                                  // 18
    var userId = Accounts.createUser(newUser);                                                                    // 19
                                                                                                                  // 20
    Meteor.users.update(userId, { $set: { profile: { name: options.name } } });                                   // 21
    Roles.setUserRoles(userId, options.roles);                                                                    // 22
                                                                                                                  // 23
    return userId;                                                                                                // 24
  },                                                                                                              // 25
});                                                                                                               // 26
                                                                                                                  // 27
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:accounts'] = {
  orion: orion
};

})();

//# sourceMappingURL=orionjs_accounts.js.map
