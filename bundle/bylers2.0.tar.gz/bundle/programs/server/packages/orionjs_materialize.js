(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var orion = Package['orionjs:attributes'].orion;
var Tabular = Package['nicolaslopezj:tabular-materialize'].Tabular;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var AccountsTemplates = Package['useraccounts:core'].AccountsTemplates;
var HTML = Package.htmljs.HTML;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var Autoupdate = Package.autoupdate.Autoupdate;

/* Package-scope variables */
var orion;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                         //
// packages/orionjs_materialize/init.js                                                    //
//                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////
                                                                                           //
Options.init('homePath');                                                                  // 1
Options.init('siteName');                                                                  // 2
Options.init('materialize.headerColor');                                                   // 3
                                                                                           // 4
ReactiveTemplates.request('tabs', 'orionMaterializeTabs');                                 // 5
                                                                                           // 6
ReactiveTemplates.request('materializeHeader', 'orionMaterializeHeaderContainer');         // 7
ReactiveTemplates.request('materializeContent', 'orionMaterializeContentContainer');       // 8
ReactiveTemplates.request('materializeButtons', 'orionMaterializeButtonsContainer');       // 9
                                                                                           // 10
ReactiveTemplates.set('layout', 'orionMaterializeLayout');                                 // 11
ReactiveTemplates.set('outAdminLayout', 'orionMaterializeOutAdminLayout');                 // 12
                                                                                           // 13
ReactiveTemplates.set('login', 'orionMaterializeLogin');                                   // 14
ReactiveTemplates.set('registerWithInvitation', 'orionMaterializeRegisterWithInvitation');
                                                                                           // 16
ReactiveTemplates.set('myAccount.index', 'orionMaterializeAccountIndex');                  // 17
ReactiveTemplates.set('myAccount.password', 'orionMaterializeAccountPassword');            // 18
ReactiveTemplates.set('myAccount.profile', 'orionMaterializeAccountProfile');              // 19
                                                                                           // 20
ReactiveTemplates.set('accounts.index', 'orionMaterializeAccountsIndex');                  // 21
ReactiveTemplates.set('accounts.update', 'orionMaterializeAccountsUpdate');                // 22
ReactiveTemplates.set('accounts.create', 'orionMaterializeAccountsCreate');                // 23
                                                                                           // 24
ReactiveTemplates.set('configUpdate', 'orionMaterializeConfigUpdate');                     // 25
ReactiveTemplates.set('dictionaryUpdate', 'orionMaterializeDictionaryUpdate');             // 26
                                                                                           // 27
// Set the default entity templates                                                        // 28
Options.set('collectionsDefaultIndexTemplate', 'orionMaterializeCollectionsIndex');        // 29
Options.set('collectionsDefaultCreateTemplate', 'orionMaterializeCollectionsCreate');      // 30
Options.set('collectionsDefaultUpdateTemplate', 'orionMaterializeCollectionsUpdate');      // 31
Options.set('collectionsDefaultDeleteTemplate', 'orionMaterializeCollectionsDelete');      // 32
                                                                                           // 33
// Orion attributes replace                                                                // 34
ReactiveTemplates.set('attribute.file', 'orionMaterializeFileAttribute');                  // 35
ReactiveTemplates.set('attribute.hasOne', 'orionMaterializeHasOneAttribute');              // 36
ReactiveTemplates.set('attribute.hasMany', 'orionMaterializeHasManyAttribute');            // 37
ReactiveTemplates.set('attribute.user', 'orionMaterializeHasOneAttribute');                // 38
ReactiveTemplates.set('attribute.users', 'orionMaterializeHasManyAttribute');              // 39
                                                                                           // 40
// Pages                                                                                   // 41
ReactiveTemplates.set('pages.index', 'orionMaterializePagesIndex');                        // 42
ReactiveTemplates.set('pages.create', 'orionMaterializePagesCreate');                      // 43
ReactiveTemplates.set('pages.update', 'orionMaterializePagesUpdate');                      // 44
ReactiveTemplates.set('pages.delete', 'orionMaterializePagesDelete');                      // 45
                                                                                           // 46
if (Meteor.isClient) {                                                                     // 47
  AutoForm.setDefaultTemplate('materialize');                                              // 48
                                                                                           // 49
  AutoForm.addHooks(null, {                                                                // 50
    beginSubmit: function() {                                                              // 51
      Session.set('orion_autoformLoading', true);                                          // 52
    },                                                                                     // 53
    endSubmit: function() {                                                                // 54
      Session.set('orion_autoformLoading', false);                                         // 55
    }                                                                                      // 56
  });                                                                                      // 57
                                                                                           // 58
  Template.registerHelper('orion_autoformLoading', function() {                            // 59
    return Session.get('orion_autoformLoading') ? 'disabled': '';                          // 60
  });                                                                                      // 61
                                                                                           // 62
                                                                                           // 63
  Template.registerHelper('materializeHeader', function() {                                // 64
    return ReactiveTemplates.get('materializeHeader');                                     // 65
  });                                                                                      // 66
                                                                                           // 67
  Template.registerHelper('materializeContent', function() {                               // 68
    return ReactiveTemplates.get('materializeContent');                                    // 69
  });                                                                                      // 70
                                                                                           // 71
  Template.registerHelper('materializeButtons', function() {                               // 72
    return ReactiveTemplates.get('materializeButtons');                                    // 73
  });                                                                                      // 74
}                                                                                          // 75
                                                                                           // 76
/////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                         //
// packages/orionjs_materialize/tabular.js                                                 //
//                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////
                                                                                           //
orion.collections.onCreated(function() {                                                   // 1
  var self = this;                                                                         // 2
  // if the collection doesn't has the tabular option, nothing to do here!                 // 3
  if (!_.has(this, 'tabular')) return;                                                     // 4
                                                                                           // 5
  var tabularOptions = _.extend({                                                          // 6
    name: 'tabular_' + self.name,                                                          // 7
    collection: self,                                                                      // 8
    columns: [                                                                             // 9
      { data: "_id", title: "ID" }                                                         // 10
    ],                                                                                     // 11
    selector: function(userId) {                                                           // 12
      var selectors = Roles.helper(userId, 'collections.' + self.name + '.indexFilter');   // 13
      return { $or: selectors };                                                           // 14
    },                                                                                     // 15
    language: {                                                                            // 16
      search: i18n('tabular.search'),                                                      // 17
      info: i18n('tabular.info'),                                                          // 18
      infoEmpty: i18n('tabular.infoEmpty'),                                                // 19
      lengthMenu: i18n('tabular.lengthMenu'),                                              // 20
      emptyTable: i18n('tabular.emptyTable'),                                              // 21
      paginate: {                                                                          // 22
        first: i18n('tabular.paginate.first'),                                             // 23
        previous: i18n('tabular.paginate.previous'),                                       // 24
        next: i18n('tabular.paginate.next'),                                               // 25
        last: i18n('tabular.paginate.last'),                                               // 26
      }                                                                                    // 27
    }                                                                                      // 28
  }, this.tabular);                                                                        // 29
                                                                                           // 30
  Tracker.autorun(function () {                                                            // 31
    tabularOptions.columns.map(function (column) {                                         // 32
      if (_.isFunction(column.title)) {                                                    // 33
        column.langTitle = column.title;                                                   // 34
      }                                                                                    // 35
      if (_.isFunction(column.langTitle)) {                                                // 36
        column.title = column.langTitle();                                                 // 37
      }                                                                                    // 38
      return column;                                                                       // 39
    });                                                                                    // 40
    self.tabularTable = new Tabular.Table(tabularOptions);                                 // 41
  });                                                                                      // 42
});                                                                                        // 43
                                                                                           // 44
/////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orionjs:materialize'] = {
  orion: orion
};

})();

//# sourceMappingURL=orionjs_materialize.js.map
