(function(){// orion.dictionary.addDefinition('facebookUrl', 'social', {
//   type: String
// });

// orion.dictionary.addDefinition('facebookIcon', 'social',
//   orion.attribute('image')
// );

// orion.dictionary.addDefinition('twitterUrl', 'social', {
//   type: String
// });

// orion.dictionary.addDefinition('twitterIcon', 'social',
//   orion.attribute('image')
// );

// orion.dictionary.addDefinition('instagramUrl', 'social', {
//   type: String
// });

// orion.dictionary.addDefinition('instagramIcon', 'social',
//   orion.attribute('image')
// );

orion.dictionary.addDefinition('Icon 1 URL', 'social', {
  type: String
});

orion.dictionary.addDefinition('Icon 1 image', 'social',
  orion.attribute('image')
);

orion.dictionary.addDefinition('Icon 2 URL', 'social', {
  type: String
});

orion.dictionary.addDefinition('Icon 2 image', 'social',
  orion.attribute('image')
);

orion.dictionary.addDefinition('Icon 3 URL', 'social', {
  type: String
});

orion.dictionary.addDefinition('Icon 3 image', 'social',
  orion.attribute('image')
);


orion.dictionary.addDefinition('Icon 4 URL', 'social', {
  type: String
});

orion.dictionary.addDefinition('Icon 4 image', 'social',
  orion.attribute('image')
);

orion.dictionary.addDefinition('Icon 5 URL', 'social', {
  type: String
});

orion.dictionary.addDefinition('Icon 5 image', 'social',
  orion.attribute('image')
);

orion.dictionary.addDefinition('Icon 6 URL', 'social', {
  type: String
});

orion.dictionary.addDefinition('Icon 6 image', 'social',
  orion.attribute('image')
);
}).call(this);

//# sourceMappingURL=social.js.map
