(function(){// orion.dictionary.addDefinition('logo', 'footer', 
//   orion.attribute('image', {
//       label: 'Footer Logo'
//   })
// );

// orion.dictionary.addDefinition('linksTitle', 'footer', {
//   type: String
// });
}).call(this);

//# sourceMappingURL=footer.js.map
