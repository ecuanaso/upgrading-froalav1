(function(){// orion.dictionary.addDefinition('logo', 'brand', 
//   orion.attribute('image', {
//       label: 'Site Logo',
//       optional: true
//   })
// );
}).call(this);

//# sourceMappingURL=brand.js.map
