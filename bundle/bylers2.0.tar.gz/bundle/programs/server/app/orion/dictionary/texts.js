(function(){// orion.dictionary.addDefinition('tituloDecoradores', 'texts', {
//   type: String
// });
}).call(this);

//# sourceMappingURL=texts.js.map
