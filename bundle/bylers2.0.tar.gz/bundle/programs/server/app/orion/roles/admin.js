(function(){var role = Roles._adminRole;

role.deny('collections.favorites.index', true);
role.deny('collections.projects.index', true);
}).call(this);

//# sourceMappingURL=admin.js.map
