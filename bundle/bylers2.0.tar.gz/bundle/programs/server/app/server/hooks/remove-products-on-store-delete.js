(function(){Meteor.startup(function() {
  Stores.after.remove(function(userId, doc) {
    Products.remove({ storeId: doc._id });
  });
});

}).call(this);

//# sourceMappingURL=remove-products-on-store-delete.js.map
