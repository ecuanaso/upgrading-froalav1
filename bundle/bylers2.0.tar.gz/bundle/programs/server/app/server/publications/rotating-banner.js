(function(){Meteor.publish('banners', function() {
  return RotatingBanner.find({}, { sort: { position: 1 } });
});
}).call(this);

//# sourceMappingURL=rotating-banner.js.map
