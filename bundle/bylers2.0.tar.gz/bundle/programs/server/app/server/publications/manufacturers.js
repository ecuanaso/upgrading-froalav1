(function(){Meteor.publish('manufacturers', function() {
  return Manufacturers.find();
});
}).call(this);

//# sourceMappingURL=manufacturers.js.map
