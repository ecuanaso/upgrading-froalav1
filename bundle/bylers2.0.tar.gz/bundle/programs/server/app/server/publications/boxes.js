(function(){Meteor.publish('boxes', function() {
  return Boxes.find();
});
}).call(this);

//# sourceMappingURL=boxes.js.map
