(function(){Meteor.publish(null, function () {
  return Favorites.find({ userId: this.userId });
});

Meteor.publishComposite('favoritesDetail', function() {
  var userId = this.userId;
  return {
    find: function() {
        return Favorites.find({ userId: this.userId });
    },
    children: [
      {
        find: function(favorite) {
          return Products.find({ _id: favorite.product, hidden: { $ne: true } });
        }
      }
    ]
  }
});

}).call(this);

//# sourceMappingURL=favorites.js.map
