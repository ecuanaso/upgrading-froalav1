(function(){Meteor.publish('recipients', function(){
  return Recipients.find();
});
}).call(this);

//# sourceMappingURL=recipients.js.map
